print("start")
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import ticker
from torchvision import datasets, transforms
import sys
import random
import argparse
sys.path.append('../../../')
from src.models.frequency.sketch_algorithms import SketchQueryalgorithms
from src.datasets.zipf import get_zipf_probs, get_dataset_samples, ZipfOnlineDatasetLoader
device = 'cuda:0'


def compute_optimal(space_beta,space_alpha,df_bf,size):
    # Define optimum cm and cs
    optimum_bf = pd.DataFrame(columns =['alpha', 'beta','d','w','MSE','sd_MSE'])

    # For each alpha and beta take the w and the d that have the smaller error in all the runs
    for beta in range(len(space_beta)):
        for alpha in range(len(space_alpha)):
            ## Count sketch
            df_BF = df_bf[(df_bf['alpha']==space_alpha[alpha].item()) & (df_bf['beta']==space_beta[beta].item())]
            (unique_w, counts_w) = np.unique(df_BF['w'], return_counts=True)
            idx_w = np.argsort(counts_w)[len(counts_w)-1]
            (unique_d, counts_d) = np.unique(df_BF['d'], return_counts=True)
            idx_d = np.argsort(counts_d)[len(counts_d)-1]
            optimum_bf = optimum_bf.append({'alpha': space_alpha[alpha].item() , 'beta': space_beta[beta].item(), 'd': unique_d[idx_d], 'w':unique_w[idx_w],'MSE':df_BF['MSE'].mean(),'sd_MSE':df_BF['MSE'].std()},ignore_index = True)


    # optimum_cm[(optimum_cm['alpha']==space_alpha[3].item()) & (optimum_cm['beta']==space_beta[3].item())]
    ## Save dataframes
    optimum_bf.to_csv('../../../results/benchmark_wd/optimum_w_d_BF_sketch_' + str(size) +'.csv') 


def compute_df(list_w,list_d,space_alpha,space_beta,runs,num_samples,n_dims,err_bf,sketch_size):
    # Compute the optimal d and w for each beta and alpha and for each run
    # Sort the vector (first position: beta, second: alpha, third: w or d) and take indexes to know which w and d are
    df_bf = pd.DataFrame(columns =['run','alpha', 'beta','d','w','MSE'])
    for run in range(runs):
        for beta in range(len(space_beta)):
            for alpha in range(len(space_alpha)):
                idx_bf = np.argsort(err_bf[run][beta][alpha])[0]
                df_bf = df_bf.append({'alpha': space_alpha[alpha].item() , 'beta': space_beta[beta].item(), 'd': list_d[idx_bf], 'w':list_w[idx_bf],'MSE':err_bf[run][beta][alpha][idx_bf],'run':run},ignore_index = True)

    # Take the optimal d and w of each run, and save a csv with the best d and w for each combination of alpha and beta
    compute_optimal(space_beta,space_alpha,df_bf,sketch_size)


def main(sketch_size):
    """
    Objective: Compute the errors of the bloom filter algorithm with different generations of the dataset (different alphas and betas) and with different combinations of d and w with a fixed sketch size.
    Each combination is repeated 10 times (runs)
    Inputs:
        - Sketch size
    Output: 
        - Save one file per algorithm with all the combinations of parameters
    """
    # Fix sketch size (1000)
    if sketch_size == 1000:
        list_w = [1,2,4,5,8,10,20,25,40,50,100,125,200,250,500,1000] 
        list_d = [1000,500,250,200,125,100,50,40,25,20,10,8,5,4,2,1] 

    # Fix sketch size (500)
    if sketch_size == 500:
        list_w = [1,2,4,5,10,20,25,50,100,125,250,500] 
        list_d = [500,250,125,100,50,25,20,10,5,4,2,1] 


    # Fix sketch size (100)
    if sketch_size == 100:
        list_w = [1,2,4,5,10,20,25,50,100] 
        list_d = [100,50,25,20,10,5,4,2,1] 

    # Fix sketch size (10)
    if sketch_size == 10:
        list_w = [1,2,5,10]
        list_d = [10,5,2,1] 

    space_alpha = torch.linspace(0.0, 2.0, 20) # 50 1-3
    space_beta = torch.linspace(0, 1.0, 5) # 50
    runs = 10
    num_samples = 10 
    n_dims = 1000 # Input dimention
    err_bf = np.zeros([runs,len(space_beta),len(space_alpha),len(list_w)])

    for run in range(runs):
        iter_beta = 0
        for beta in list(space_beta):
            iter_alpha = 0
            for alpha in list(space_alpha):
                # Generating dataset 
                zipfdatasetloader = ZipfOnlineDatasetLoader(500, n_dims, num_samples, alpha_min=alpha, alpha_max=alpha,beta_min=beta, beta_max=beta,device=device)
                
                errors_bf = []
                # For each d and w
                for i in range(len(list_w)):
                    w = list_w[i]
                    d = list_d[i]
                    # Compute bloom filter
                    bloom_filter = SketchQueryalgorithms(n_dims, w, d,'BF')
                    err = []
                    # Iterate the batches and take just the first batch
                    for j, (x,y) in enumerate(zipfdatasetloader):
                        if j == 0:     
                            for batch in range(x.shape[0]):
                                x_i = x[batch].cpu()
                                y_i = y[batch].cpu()

                                # If the mean > 1, the feature is in the dataset
                                y_i[y_i==0]=0
                                y_i[y_i>0] = 1
                                # Compute BF
                                y_hat, s = bloom_filter.SketchQuery_algorithms(x_i)
                                error = torch.mean(torch.square(torch.clamp(y_hat, 0, 1)-y_i.squeeze()))
                                err.append(error.item())
                            errors_bf.append(np.mean(err))

                err_bf[run,iter_beta,iter_alpha,:] = errors_bf
                iter_alpha += 1
            iter_beta += 1


    #save to file
    np.save('../../../results/benchmark_wd/error_MSE_BF_Sketch'+str(sketch_size)+'alpha0-2_numsamples10', err_bf)

    # convert numpy to dataframe and take the best w and d for each combination of alpha and beta
    compute_df(list_w,list_d,space_alpha,space_beta,runs,num_samples,n_dims,err_bf,sketch_size)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-Sketch_size', '--Sketch_size', type=int, help='Sketch size', required=True)    
    return parser.parse_args()
    
if __name__ == '__main__':
    args = parse_args()
    main(args.Sketch_size)

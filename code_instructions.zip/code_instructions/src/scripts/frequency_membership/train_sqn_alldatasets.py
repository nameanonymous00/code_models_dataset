print("start importing")
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys
import random
import hjson
import argparse
import os
sys.path.append('../../../')
from src.models.networks.sqnet import SketchNetwork, QueryNetworkTask, RandomFeatures, SketchNetworkResLN
from src.scripts.frequency_membership.plots import compute_test
from src.datasets.zipf import get_zipf_probs, get_dataset_samples, ZipfOnlineDatasetLoader
from src.models.frequency.sketch_algorithms import SketchQueryalgorithms
from src.datasets.read_data import load_data
print('done importing!')

## Setup device
device = 'cuda:0'


def ds_reshape( ds, dim1, dim2 ):
    """
    Reshapes the dimensions of the data to add the batch size dim (Batch_size x num_samples x num_features)
    The input parameters are the data, dim1 (batch_size) and dim2 (num_samples)
    If dim1*dim2 is bigger than the number of rows of the datasets, an error will be printed
    If dim1*dim2 is smaller than the number of rows, data will be trimmed and will have the following dimensions:(Batch_size x num_samples x num_features) 
    If dim1*dim2 is equal to the number of rows, data will have the following dimensions:(Batch_size x num_samples x num_features) 
    """        
    assert( dim1*dim2 <= ds.shape[0] )
    if  dim1*dim2 < ds.shape[0]:
        print('Warning: data will be trimmed')
        return ds[:dim1*dim2].reshape( (dim1, dim2, ds.shape[1] )) 
    else:
        return ds.reshape( ( dim1, dim2, ds.shape[1] ))
    

def define_networks(hparams,method,sketch_path,query_path):
    """
    Function that defines the sketch and query query network
    Inputs:
        - hparams: Parameters and hyperparameters of the models
        - method: sqnet or rfqnet
        - sketch_path,query_path: Paths of the networks trained with zipf datasets
    Output:
        - SN: Sketch query network
        - QN: Query network
    """
    # Define networks
    if method == 'sqnet':
        if hparams['residual_sketch_net'] == 0:
            SN = SketchNetwork(hparams['n_dims'], hparams['sketch_size'],hparams['hidden_dim']).to(device)
            # Inicialize the model trainned with zipf dataset
            SN.load_state_dict( torch.load(sketch_path, map_location=device),strict=False)

        else:
            SN = SketchNetworkResLN(hparams['n_dims'], hparams['sketch_size'],num_hidden=hparams['num_hidden']).to(device)
            # Inicialize the model trainned with zipf dataset
            SN.load_state_dict( torch.load(sketch_path, map_location=device),strict=False)
    else:
        SN = RandomFeatures(hparams['n_dims'], hparams['sketch_size'],activation=hparams['activation'], var=hparams['var']).to(device)
        # Inicialize the model trainned with zipf dataset
        SN.load_state_dict( torch.load(sketch_path, map_location=device),strict=False)
    # Inicialize the model trainned with zipf dataset
    QN = QueryNetworkTask(hparams['sketch_size'], hparams['n_dims'],hparams['hidden_dim']).to(device)
    QN.load_state_dict( torch.load(query_path, map_location=device),strict=False)
    return SN,QN





def evaluate_network(x,hparams,SN,QN,metric):
    """
    This function evaluates the sketch and query networks.
    Inputs:
        - x: test or validate data
        - hparams: parameters and hyperparameters
        - SN,QN: networks
        - metric: Metric used to compute the error
    Output: Test error
    """
    with torch.no_grad():
        # Compute the mean
        y = torch.mean(x, dim=1)
        if hparams['task'] == 'membership_estimation':
            y[y == 0] = 0
            y[y > 0] = 1
        # Sketch network
        sketch = SN(x, mean_dim=1,type_lastlayer=hparams['type_lastlayer'],order_norm=hparams['order_norm'])
        # Query network
        y_hat = torch.sigmoid(QN(sketch)).squeeze()
        # Compute error
        error = torch.mean(metric(y_hat.cpu()-y.cpu()))

    return error
    
    

def train_networks(data_train,data_val,data_test,hparams,name_dataset,method,sketch_path,query_path):
    """
    This function reshape data to have batch, num_samples and features, and trains the networks calling the corresponding functions.
    The train is stoped if the validation loss between some epohs does not decrease.
    Input:
        - data_train,data_val,data_test : Train, val, and test data
        - hparams: Parameters and hyperparameters
        - name_dataset: The name of the dataset, where the train, val, and test data comes
        - method: SQNet (sketch and query networks are trained), or RFQNet (just the query network is trained)
        - sketch_path,query_path: Path of the models trained with zipf datasets
    
    Output: Test loss
    """
    # Define networks
    SN,QN = define_networks(hparams,method,sketch_path,query_path)
    
    # Define criterion
    criterion = nn.BCEWithLogitsLoss()
    metric = torch.square
    
    # Define optimizer and several parameters
    if method == 'sqnet':
        optimizer = torch.optim.Adam([*SN.parameters(), *QN.parameters()], lr=hparams['lr_sq'], weight_decay=hparams['weight_decay'])
        hparams['batch_size'] = hparams['batch_size_sq']
        hparams['type_lastlayer'] = hparams['type_lastlayer_sq']
        hparams['order_norm'] = hparams['order_norm_sq']
    else:
        optimizer = torch.optim.Adam([*QN.parameters()], lr=hparams['lr_rf'], weight_decay=hparams['weight_decay'])  
        hparams['batch_size'] = hparams['batch_size_rf']
        hparams['type_lastlayer'] = hparams['type_lastlayer_rf']
        hparams['order_norm'] = hparams['order_norm_rf']     
 

    # If num_samples is bigger than the dataset, take the dim of the dataset
    num_samples_train = min(data_train.shape[0],hparams['num_samples_net'])
    num_samples_val = min(data_val.shape[0],hparams['num_samples'])
    num_samples_test = min(data_test.shape[0],hparams['num_samples'])
    
    # reshape data to have batch, num_samples and features (Bxnum_samplesx1000)
    data_train = ds_reshape( data_train,  int(data_train.shape[0]/num_samples_train), num_samples_train)
    data_val = ds_reshape( data_val,  int(data_val.shape[0]/num_samples_val), num_samples_val)
    data_test = ds_reshape( data_test,  int(data_test.shape[0]/num_samples_test), num_samples_test)
    
    # Batch size need to be smaller or equal than the first dim of the train data
    # If not, change the bach size
    if hparams['batch_size'] >= data_train.shape[0]:
        hparams['batch_size'] = int(data_train.shape[0]/5)
        print('batch {}'.format(hparams['batch_size']))
    
    # Define Dataloader
    dataloader = torch.utils.data.DataLoader(data_train, batch_size=hparams['batch_size'])
    
    ## Stop criterion:
    # number of epochs or the validation loss does not decrease
    stop_condition = 0
    MSE_loss =  10
    # Train the networks
    for j in range(hparams['num_epochs']):
        if stop_condition == 0:
            for i,x in enumerate(dataloader):
                x = x.to(device)
                optimizer.zero_grad()
                # Compute the mean
                y = torch.mean(x, dim=1)
                if x.shape[0] == 1:
                    break
                # Sketch network
                sketch =  SN(x, mean_dim=1,type_lastlayer=hparams['type_lastlayer'],order_norm=hparams['order_norm'])
                # Query network
                query_output = QN(sketch)
                # If membership task, if the mean is bigger than one: minumum one features is present in the dataset, so the y= 1. If not y=0
                if hparams['task'] == 'membership_estimation':
                    y[y == 0] = 0
                    y[y > 0] = 1
                
                # Compute the loss
                loss = criterion(query_output, y.float())

                loss.backward()
                optimizer.step()

            # Evaluate the network after some epochs
            if j % 5 == 0 and j != 0:
                SN.eval()
                QN.eval()
                val_loss = evaluate_network(data_val.to(device),hparams,SN,QN,metric)
                print(val_loss)
                # If the difference between the last one and the new one is smaller than 0.00001 stop training
                if np.abs(MSE_loss - val_loss) < 0.00001:
                    stop_condition = 1
                    print('stop')
                MSE_loss = val_loss
                if method == 'sqnet':
                    SN.train()
                QN.train()


    # Test network
    SN.eval()
    QN.eval()
    #print(data_test.shape)
    # Compute the test error
    loss = evaluate_network(data_test.to(device),hparams,SN,QN,metric)
    print(loss.item())
    return round(loss.item(),5)



def create_dir(name_dir):
    # Create directory to store results
    try:
        os.mkdir(name_dir)
    except OSError:
        print ("Creation of the directory %s failed" % name_dir)
    else:
        print ("Successfully created the directory %s " % name_dir)       

def main(task):
    """
    This function reads the config file depending on the task and call the corresponding functions to compute the errors of the network with each dataset.
    The input is the name of the task (frequency or membership) that is given by terminal.
    The output is a csv with the results of SQNet and RFnet for each dataset.
    """
    # Define the path of the config, depending on the task
    if task == 'frequency':
        path = '../../../configs/config_frequencymodel_sk100.txt' 
    else:
        path = '../../../configs/config_membershipmodel_sk100.txt'
    
    # Read config file of membership or frequency config_membershipmodel_sk100
    with open(path) as json_file: # config_frequencymodel_sk100
        hparams = hjson.load(json_file)
       
    # Create dir results
    create_dir(hparams['path_save_errors_trainingdatasets'])
    
    # define class that reads data
    class_read_data = load_data()
    
    # Create dataframe results
    errors = pd.DataFrame(columns=['dataset','Test error sqnet','Test error rfqnet']) 
    
    # For each dataset
    for name_dataset in hparams['names_datasets']: 
        # Read data    
        print(name_dataset)
        path = hparams['folder_datasets'] + name_dataset +'.npz'
        data_train,data_val,data_test = class_read_data.loaddata(path)   
        
        # Train sqnet
        loss_sqn = train_networks(data_train,data_val,data_test,hparams,name_dataset,'sqnet',hparams['sq_snet'],hparams['sq_qnet'])
        
        # Train rfnet
        loss_rfqn = train_networks(data_train,data_val,data_test,hparams,name_dataset,'rfnet',hparams['rf_snet'],hparams['rf_qnet'])
        
        # Add row to a csv
        #errors.append({'dataset':name_dataset,'Test error sqnet':loss_sqn,'Test error rfqnet':loss_rfqn})
        errors.loc[len(errors),errors.columns] = {'dataset':name_dataset,'Test error sqnet':loss_sqn,'Test error rfqnet':loss_rfqn}
        
    # Save mean errors
    errors.loc[len(errors),errors.columns] = {'dataset':'Average datasets','Test error sqnet':round(np.mean(errors['Test error sqnet']),4),'Test error rfqnet':round(np.mean(errors['Test error rfqnet']),4)}
    
    # Save results in a csv
    print('save results')
    print(hparams['path_save_errors_trainingdatasets'])
    if hparams['task'] == 'membership_estimation':
        errors.to_csv(hparams['path_save_errors_trainingdatasets']+'errors_membership.csv',index=False) # 10 samples
    else:
        errors.to_csv(hparams['path_save_errors_trainingdatasets']+'errors_frequency.csv',index=False) # 18 samples


        
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-task', '--task', type=str, help='frequency or membership', required=True)    
    return parser.parse_args()

        
if __name__ == '__main__':
    """
       The objective of this script is to train the SQNet and the RFNet. Each one have the sketch and query network. 
       The networks are inicialized with the networks trained with zift dataset. 
       The datasets used to train the networks are defined in the config file (They need to be binary and to have 1000 features)
       This script saves a table with the errors of the different datasets of SQNet and the RFNet.
    """
    args = parse_args()
    assert( args.task == 'frequency' or args.task == 'membership'), 'You need to add an argument to the shell command: python3 train_sqn_alldatasets.py --task (frequency or membership)' 
    main(args.task)
print("start importing")
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys
import random
import hjson
import os
sys.path.append('../../../')
from src.models.networks.sqnet import SketchNetwork, QueryNetworkTask, RandomFeatures, SketchNetworkResLN
from src.scripts.frequency_membership.plots import compute_test
from src.datasets.zipf import get_zipf_probs, get_dataset_samples, ZipfOnlineDatasetLoader
from src.models.frequency.sketch_algorithms import SketchQueryalgorithms
print('done importing!')

## Setup device
device = 'cuda:0'

def define_networks(hparams):
    """
    Function that defines the sketch and query query network
    Inputs:
        - hparams: Parameters and hyperparameters of the models
    Output:
        - SN: Sketch network
        - QN: Query network
    """
    # Define networks
    if hparams['train_SN_QN']:
        if hparams['residual_sketch_net'] == 0:
            SN = SketchNetwork(hparams['n_dims'], hparams['sketch_size'],hparams['hidden_dim']).to(device)
        else:
            SN = SketchNetworkResLN(hparams['n_dims'], hparams['sketch_size'],num_hidden=hparams['num_hidden']).to(device)
    else:
        SN = RandomFeatures(hparams['n_dims'], hparams['sketch_size'],activation=hparams['activation'], var=hparams['var']).to(device)
    QN = QueryNetworkTask(hparams['sketch_size'], hparams['n_dims'],hparams['hidden_dim']).to(device)
    return SN,QN

    
def train_network(hparams):
    """
    The objective of this function is to train the Sketch and Query networks (SQNet), or just train the Query network (RFQNet).
    Input:
        - hparams: Hyper-parameters and parameters
    Output:
        - SN: Sketch query network
        - QN: Query network
        - Save plots:
            - Save a png with the losses of the epochs
    """
    
    ## Neural net training 
    losses = []
    print('Setting up training!!!')
    
    # Define networks
    SN,QN = define_networks(hparams)
    
    # Define criterion
    criterion = nn.BCEWithLogitsLoss()#nn.MSELoss()#nn.KLDivLoss()#nn.BCEWithLogitsLoss()
    
    # Define optimizer
    if hparams['train_SN_QN']:
        optimizer = torch.optim.Adam([*SN.parameters(), *QN.parameters()], lr=hparams['lr'], weight_decay=hparams['weight_decay'])
    else:
        optimizer = torch.optim.Adam([*QN.parameters()], lr=hparams['lr'], weight_decay=hparams['weight_decay'])
        
    batch_size, num_samples =  hparams['batch_size'], hparams['num_samples_net']  
    
    # Define alpha, and beta values and the dataset class
    if hparams['task'] == 'frequency_estimation':
        alpha_min=0.0
        alpha_max=2.0
        
        # Define class
        zipfdatasetloader = ZipfOnlineDatasetLoader(batch_size, hparams['n_dims'], num_samples, alpha_min=alpha_min, alpha_max=alpha_max,device=device)
    else:
        alpha_min=0.0 # CHANGE 1.0
        alpha_max=2.0    
        beta_min=0.5 
        beta_max=0.5          
        
        # Define class
        zipfdatasetloader = ZipfOnlineDatasetLoader(batch_size, hparams['n_dims'], num_samples, alpha_min=alpha_min, alpha_max=alpha_max,beta_min=beta_min, beta_max=beta_max,device=device)

    print('Start training!!!')
    print('num epochs are', hparams['num_epochs'])
    
    # Train the networks
    for j in range(hparams['num_epochs']):
        
        with torch.no_grad():
            # Define num samples and batch size
            if hparams['task'] == 'frequency_estimation':
                # Each epoch the num samples is randomly chosen. The number can be from 1 to 20
                zipfdatasetloader.num_samples_per_batch = torch.randint(1, 20, (1,))
                zipfdatasetloader.batch_size = int(batch_size/int(zipfdatasetloader.num_samples_per_batch))
            else:
                # Each epoch the num_samples is the sampe
                zipfdatasetloader.num_samples_per_batch = hparams['num_samples_net'] 
                zipfdatasetloader.batch_size = hparams['batch_size']
                #zipfdatasetloader.num_samples_per_batch = torch.randint(1, 10, (1,))
                #zipfdatasetloader.batch_size = int(batch_size/int(zipfdatasetloader.num_samples_per_batch))
                # Every 5 epochs the value of alpha will be between 0.75-1.5, the other epochs between 0-2.
                if j % 5  == 0:            
                    zipfdatasetloader.alpha_min = 0.75 #2.0
                    zipfdatasetloader.alpha_max = 1.5 #2.0
                else:
                    zipfdatasetloader.alpha_min = 0.0
                    zipfdatasetloader.alpha_max = 2.0 #2.0

        # For each batch
        for i, (x,y) in enumerate(zipfdatasetloader):
            # The dimension of x is: batch_size x num_samples x features
            optimizer.zero_grad()
            # Compute sketch network
            sketch =  SN(x, mean_dim=1,type_lastlayer=hparams['type_lastlayer'],order_norm=hparams['order_norm'])
            # Compute query network
            query_output = QN(sketch)
            # If membership task, if the mean is bigger than one: minumum one features is present in the dataset, so the y= 1. If not y=0
            if hparams['task'] == 'membership_estimation':
                y[y == 0] = 0
                y[y > 0] = 1
            
            # Compute loss
            loss = criterion(query_output, y.float())

            loss.backward()
            optimizer.step()

        # Append loss
        losses.append(loss.item())

    # Print plot train loss
    plt.close()
    plt.plot(losses)
    if hparams['save_plots']:
        plt.title('Train loss {}:{}'.format(hparams['name_hyperparam'],i))
        name_file = hparams['PATH'] + '/' +'loss.png'
        plt.savefig(name_file) 
    else:
        plt.title('Train loss')
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.show()
    plt.close()
    
    return SN, QN


        
def eval_network(hparams,SN,QN):
    """
    The objective of this function is to evaluate the networks and execute countsketch,countmin in the frequency estimation task.
    Evaluates the methods ploting the mean of the real features, and the mean of the features at the output of the algorithms.
    Input:
        - hparams: Hyper-parameters and parameters
        - SN: Sketch query network
        - QN:query network        
    Output:
        - countsketch
        - countmin
        - Save plots:
            - Save a png with the mean real data
            - Save a png with the SQNet reconstruction
            - Save a png with the Count Sketch Reconstruction
    """
    # w*d have to be equal the sketch size
    assert hparams['sketch_size'] == hparams['w']*hparams['d']
    # Define the algorithms
    countmin = SketchQueryalgorithms(hparams['n_dims'], hparams['w'], hparams['d'],'CM')
    countsketch = SketchQueryalgorithms(hparams['n_dims'],hparams['w'], hparams['d'],'CS')
    bloom_filters = SketchQueryalgorithms(hparams['n_dims'],hparams['w'], hparams['d'],'BF')
    
    # Plot the mean of the real data
    if hparams['task'] == 'frequency_estimation':
        ## Generating dataset
        num_samples = hparams['num_samples_fm']
        ps = get_zipf_probs(hparams['n_dims'], hparams['alpha'], hparams['beta'])
        dset = torch.bernoulli(ps.repeat(num_samples,1))
        x = dset.to(device)
        y = torch.mean(x, dim=0)
        # Plot the mean of the dataset
        plt.plot(y.cpu().detach().numpy())
        plt.title('Real frequency')
        if hparams['save_plots']:
            name_file = hparams['PATH'] + '/' +'real_mean.png'
            plt.savefig(name_file)   
        plt.xlabel("Dataset features")
        plt.ylabel("Frequency")
        plt.show()
        plt.close()

    ## Estimated frequency from trained SQNet
    
    if hparams['train_SN_QN']:
        SN.eval()
    QN.eval()
    
    # Plot the mean of the SQNet and the CS
    if hparams['task'] == 'frequency_estimation':
        with torch.no_grad():
            x_ = x.unsqueeze(0)
            sketch = SN(x_, mean_dim=1,type_lastlayer=hparams['type_lastlayer'],order_norm=hparams['order_norm'])
            y_hat = torch.sigmoid(QN(sketch)).squeeze()
            error = torch.mean(torch.square(y_hat-y))
            print(f'MSE is {error}')
        plt.plot(y_hat.cpu().detach().numpy())
        plt.title('SQNet Reconstruction')
        if hparams['save_plots']:
            name_file = hparams['PATH'] + '/' +'SQNet_Reconstruction.png'
            plt.savefig(name_file)  
        plt.xlabel("Dataset features")
        plt.ylabel("Frequency")
        plt.show()
        plt.close()


        ## Estimated frequency from Count-Sketch
        y_hat, s = countsketch.SketchQuery_algorithms(x.to('cpu'))
        error = torch.mean(torch.square(y_hat-y.cpu()))
        print(f'MSE is {error}')
        plt.plot(y_hat.cpu().detach().numpy())
        plt.title('CS Reconstruction')
        if hparams['save_plots']:
            name_file = hparams['PATH'] + '/' +'CS_Reconstruction.png'
            plt.savefig(name_file) 
        plt.xlabel("Dataset features")
        plt.ylabel("Frequency")
        plt.show()
        plt.close()
    return countsketch,countmin,bloom_filters,SN,QN


def create_dir(name_dir):
    # Create directory to store results
    try:
        os.mkdir(name_dir)
    except OSError:
        print ("Creation of the directory %s failed" % name_dir)
    else:
        print ("Successfully created the directory %s " % name_dir)       

def main():
    """
    This function reads the config files and calls the corresponding functions to train the networks.
    The output are the saved models.
    If variable save_data is 1, a folder is going to be created inside the folder results and the loss plot is going to be saved.
    The models are saved in the path defined in the config
    """
    # Read config sqnet
    with open('../../../configs/config_network.txt') as json_file:
        hparams = hjson.load(json_file)
        
    # Read config CM/CS/BF
    with open('../../../configs/config_frequencymodels.txt') as json_file:
        hparams_1 = hjson.load(json_file)
    
    # Create dir results
    #create_dir('results')
    
    # Join the two json in hparams
    hparams.update(hparams_1)
    
    # If hparams['both_sq_rfq'] is true , the sqnet and rfqnet are executed and the models are saved.
    # If hparams['both_sq_rfq'] is false, just the sqnet or rfqnet are trained.
    if hparams['both_sq_rfq']:
        hparams['list_hyperparam'] = [0,1]
        hparams['name_hyperparam'] = 'train_SN_QN'
        
    #for type_ in ['relu','gelu','tanh','sigmoid','cos','sin','rff']:
    #hparams['activation'] = type_    
    # Try different parameters
    for i in hparams['list_hyperparam']:
        # Take the corresponding d and w depending of the sketch size
        if hparams['sketch_size']== 10:
            hparams['w'] = hparams['w_list'][0]
            hparams['d'] = hparams['d_list'][0]
        elif hparams['sketch_size']== 100:
            hparams['w'] = hparams['w_list'][1]
            hparams['d'] = hparams['d_list'][1]  
        elif hparams['sketch_size']== 500:
            hparams['w'] = hparams['w_list'][2]
            hparams['d'] = hparams['d_list'][2]
        elif hparams['sketch_size']== 1000:
            hparams['w'] = hparams['w_list'][3]
            hparams['d'] = hparams['d_list'][3]
        print('{} : {}'.format(hparams['name_hyperparam'],i))
        hparams[hparams['name_hyperparam']] = i

        # Take the parameters acording if we are training the sqnet or rfqnet
        if hparams['train_SN_QN']==0:
            hparams['lr'] = hparams['lr_rf']
            hparams['batch_size'] = hparams['batch_size_rf']
            hparams['type_lastlayer'] = hparams['type_lastlayer_rf']
            hparams['order_norm'] = hparams['order_norm_rf']
        else:
            hparams['lr'] = hparams['lr_sq']
            hparams['batch_size'] = hparams['batch_size_sq']  
            hparams['type_lastlayer'] = hparams['type_lastlayer_sq']
            hparams['order_norm'] = hparams['order_norm_sq']

    
        # Create directory to store results
        if hparams['save_plots']:
            if hparams['both_sq_rfq']:   
                hparams['PATH'] = '../../../results/results_loss_trained_zipf/' + hparams['task'] + str(hparams['sketch_size']) + '_both' + str(hparams['both_sq_rfq']) + '_' + hparams['type_lastlayer']
            else:
                hparams['PATH'] = '../../../results/results_loss_trained_zipf/' + hparams['task'] + str(hparams['sketch_size']) + '_' + str(hparams['train_SN_QN']) + '_'  + hparams['name_hyperparam'] + '_' + str(i) + hparams['type_lastlayer'] 

            # Create dir results
            print(hparams['PATH'])
            create_dir('../../../results/results_loss_trained_zipf/')
            create_dir(hparams['PATH'])
            
            
        # Train SQ (Sketch network) and QN (query network)
        SN, QN = train_network(hparams)
        
        # Evaluate network ploting the mean of the features and execute countsketch,countmin int he frequency estimation task
        #countsketch,countmin,bloom_filters,SN, QN = eval_network(hparams,SN,QN)

        # Save the networks
        if hparams['train_SN_QN']==0:
            path = hparams['path_networks_rfqnet']
        else:
            path = hparams['path_networks_sqnet']
            
        save_path_SN =  path + 'snet_sq_'+str(i)+'.pth'
        save_path_QN =  path + 'qnet_sq_'+str(i)+'.pth'              
        torch.save(SN.state_dict(), save_path_SN)
        torch.save(QN.state_dict(), save_path_QN)        


        
if __name__ == '__main__':
    """
    This script trains the sketch and query network in the SQNet and/or just the query network in the RFQNet.
    The output are the saved networks
    """
    main()
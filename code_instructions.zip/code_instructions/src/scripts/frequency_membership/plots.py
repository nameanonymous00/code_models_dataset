print("start importing")
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys
import os
import random
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
sys.path.append('../../../')
from src.datasets.zipf import get_zipf_probs, get_dataset_samples, ZipfOnlineDatasetLoader
from src.models.frequency.sketch_algorithms import SketchQueryalgorithms


def create_dir(name_dir):
    # Create directory to store results
    try:
        os.mkdir(name_dir)
    except OSError:
        print ("Creation of the directory %s failed" % name_dir)
    else:
        print ("Successfully created the directory %s " % name_dir)      
        

def compute_plot_zoomalpha(err,names,colors,space,Beta,hparams):
    """
    This function saves a plot with the errors of all the methods, doing zoom in the alpha (x axis).
    Input parameters:
        - err: Matrix where the errors of the different methods are going to be stored
        - names: Names of the models that are going to be evaluated
        - colors: List of colors. Definition of the colors of each model
        - space: List of alphas that are going to be used to create the dataframe
        - Beta: Beta used to create the dataframe
        - hparams:  Parameters and hyperparameters of the models
    """
    # Define figure and subplot
    fig = plt.figure(figsize=(13, 4)) 
    ax1 = plt.subplot(1,2,1)
    
    for i in range(len(err)):
        if names[i]=='BF' or names[i]=='CS' or names[i]=='CM':
            # If the names are BF,CS/CM concat the d and w used, to the string that is going to be used as label
            n = names[i] + ' (W={},D={})'.format(hparams['w'],hparams['d'])
        else:
            n = names[i]
        # The optimum models of CM/CS/BF are ploted with dashed lines
        if names[i]=='Count-Sketch (Optim)' or names[i]=='Count-Min (Optim)' or names[i]=='Bloom-filter (Optim)':
            ax1.plot(space,err[i],label=n,color=colors[i],ls='dashed')    
        else:
            ax1.plot(space,err[i],label=n,color=colors[i])    
    
    plt.xlabel("Alpha")
    plt.ylabel("MSE")

    # Define the zoom in alpha
    half = int(len(space)/2) # 2
    ax2 = plt.subplot(1,2,2) # rows,columns, fig
    
    for i in range(len(err)):
        if names[i]=='BF' or names[i]=='CS' or names[i]=='CM':
            # If the names are BF,CS/CM concat the d and w used, to the string that is going to be used as label
            n = names[i] + ' (W={},D={})'.format(hparams['w'],hparams['d'])
        else:
            n = names[i]
        # The optimum models of CM/CS/BF are ploted with dashed lines
        if names[i]=='Count-Sketch (Optim)' or names[i]=='Count-Min (Optim)' or names[i]=='Bloom-filter (Optim)':
            error = err[i]
            ax2.plot(space[half:],error[half:],label=n,color=colors[i],ls='dashed')    
        else:
            error = err[i]
            ax2.plot(space[half:],error[half:],label=n,color=colors[i])    
            
    ax2.yaxis.tick_right()
    plt.xlabel("Alpha")

    plt.xlim([space[half], space[len(space)-1]])

    #fig.suptitle("Loss of the algorithms with different alphas and Beta {}".format(Beta), fontsize=12)
    # Insert the zoom box and lines
    mark_inset(ax1, ax2, loc1=2, loc2=3, fc="none", ec="0.5")
    #plt.legend(bbox_to_anchor=(-0.6, -0.55, 1., .102),
    #   ncol=4, mode="expand", borderaxespad=-7.0,prop={'family':'Serif','size':12})
    
    plt.legend(bbox_to_anchor=(-0.6, -0.60, 1., .102),
       ncol=4, mode="expand", borderaxespad=-7.0,prop={'family':'Serif','size':10})
    #plt.show()
    if hparams['save_plots']:
        print(Beta)
        # If dir does not exist, created
        create_dir(hparams['path_save_plots'])
        name_file = hparams['path_save_plots'] +'All_methods_zoomalpha_Beta_' + str(Beta) + hparams['task']+ '.png'
        #plt.savefig(name_file,dpi=300) 
        plt.savefig(name_file, bbox_inches='tight') # bbox_extra_artists=(lgd,)
        plt.show()
    else:
        #plt.savefig('freq_all_methods_best_Beta_' + str(Beta) + '.png', bbox_inches='tight')
        plt.show()
    plt.close()
    
    
def compute_plot_zoomMSE(err,names,colors,space,Beta,hparams):
    """
    This function saves a plot with the errors of all the methods, doing zoom in the MSE (y axis).
    Input parameters:
        - err: Matrix where the errors of the different methods are going to be stored
        - names: Names of the models that are going to be evaluated
        - colors: List of colors. Definition of the colors of each model
        - space: List of alphas that are going to be used to create the dataframe
        - Beta: Beta used to create the dataframe
        - hparams:  Parameters and hyperparameters of the models
    """
    # Define figure and subplot
    fig = plt.figure(figsize=(13, 4)) 
    ax1 = plt.subplot(1,2,1)
    
    # For each error, draw a line
    for i in range(len(err)):
        # If the names are BF,CS/CM concat the d and w used, to the string that is going to be used as label
        if names[i]=='BF' or names[i]=='CS' or names[i]=='CM':
            n = names[i] + ' (W={},D={})'.format(hparams['w'],hparams['d'])
        else:
            n = names[i]
        # The optimum models of CM/CS/BF are ploted with dashed lines
        if names[i]=='Count-Sketch (Optim)' or names[i]=='Count-Min (Optim)' or names[i]=='Bloom-filter (Optim)':
            ax1.plot(space,err[i],label=n,color=colors[i],ls='dashed')    
        else:
            ax1.plot(space,err[i],label=n,color=colors[i])    
            
    plt.xlabel("Alpha")
    plt.ylabel("MSE")
    
    # Define axis 2
    ax2 = plt.subplot(1,2,2) # rows,columns, fig
    
    for i in range(len(err)):
        # If the names are BF,CS/CM concat the d and w used, to the string that is going to be used as label
        if names[i]=='BF' or names[i]=='CS' or names[i]=='CM':
            n = names[i] + ' (W={},D={})'.format(hparams['w'],hparams['d'])
        else:
            n = names[i]
        # The optimum models of CM/CS/BF are ploted with dashed lines
        if names[i]=='Count-Sketch (Optim)' or names[i]=='Count-Min (Optim)' or names[i]=='Bloom-filter (Optim)':
            ax2.plot(space,err[i],label=n,color=colors[i],ls='dashed')    
        else:
            ax2.plot(space,err[i],label=n,color=colors[i])    
            
    ax2.yaxis.tick_right()
    plt.xlabel("Alpha")
    #plt.ylabel("MSE")

    # Limit the x and y axis
    if hparams['task'] == 'frequency_estimation':  
        plt.ylim([0, 0.004]) 
        plt.xlim([0.1, 2.0])
    else:
        plt.ylim([0, 0.3])
        plt.xlim([0.1, 2.0]) #1.1
    
    #fig.suptitle("Loss of the algorithms with different alphas and Beta {}".format(Beta), fontsize=12)
    # Insert the zoom box and lines
    mark_inset(ax1, ax2, loc1=2, loc2=3, fc="none", ec="0.5")
    #plt.legend(bbox_to_anchor=(-0.6, -0.55, 1., .102),
    #   ncol=4, mode="expand", borderaxespad=-7.0,prop={'family':'Serif','size':12})
    plt.legend(bbox_to_anchor=(-0.6, -0.60, 1., .102),
       ncol=4, mode="expand", borderaxespad=-7.0,prop={'family':'Serif','size':10})
    #plt.show()
    if hparams['save_plots']:
        print(Beta)
        create_dir(hparams['path_save_plots'])
        name_file = hparams['path_save_plots'] +'All_methods_zoomMSE_Beta_' + str(Beta) + hparams['task']+ '.png'
        #plt.savefig(name_file,dpi=300) 
        plt.savefig(name_file, bbox_inches='tight') # bbox_extra_artists=(lgd,)
        plt.show()
    else:
        #plt.savefig('freq_all_methods_best_2_Beta_' + str(Beta) + '.png', bbox_inches='tight')
        plt.show()
    plt.close()    
    
    
    
    
def compute_non_optimal(x,y,err,hparams,metric,device,space_i,names):    
    """
    This function return the errors of CS/CM or bloom filters with a specific w and d.
    Input parameters:
        - x: Data 
        - y: Mean of the data
        - err: Matrix where the errors of the different methods are going to be stored
        - hparams: Parameters and hyperparameters of the models
        - metric: Used to compute the errors
        - device: Gpu
        - space_i: Iteration od alpha
        - names: Names of the models that are going to be evaluated
    Output parameters:
        - err: Matrix where the errors of the different methods are stored
    """
    
    # Define lists to store the result of each batch
    error_CM = []
    error_CS = []
    error_BF = []
    
    if hparams['task'] == 'frequency_estimation':
        # Define the methods with the corresponding d and w
        countmin = SketchQueryalgorithms(hparams['n_dims'], hparams['w'], hparams['d'],'CM')
        countsketch = SketchQueryalgorithms(hparams['n_dims'],hparams['w'], hparams['d'],'CS')
        
        # For each batch
        for batch in range(x.shape[0]):
            x_i = x[batch].cpu()
            y_i = y[batch].cpu()
            
            # Compute CS
            y_hat, s = countsketch.SketchQuery_algorithms(x_i)
            error = torch.mean(metric(torch.clamp(y_hat, 0, 1)-y_i.squeeze()))
            error_CS.append(error.item()) 
           
            # Compute CM
            y_hat, s = countmin.SketchQuery_algorithms(x_i)
            error = torch.mean(metric(torch.clamp(y_hat, 0, 1)-y_i.squeeze()))
            error_CM.append(error.item()) 
        
        # Append the mean of the batches to the err matrix
        err[names.index('CS'),space_i] = np.mean(error_CS)  
        err[names.index('CM'),space_i] = np.mean(error_CM)  
        
    else:
        # Define the methods with the corresponding d and w
        bloom_filters = SketchQueryalgorithms(hparams['n_dims'],hparams['w'], hparams['d'],'BF')  
        # For each batch
        for batch in range(x.shape[0]):
            x_i = x[batch].cpu()
            y_i = y[batch].cpu()
            # Compute BF
            y_hat, s = bloom_filters.SketchQuery_algorithms(x_i)
            error = torch.mean(metric(torch.clamp(y_hat, 0, 1)-y_i.squeeze()))
            error_BF.append(error.item()) 
        
        # Append the mean of the batches to the err matrix
        err[names.index('BF'),space_i] = np.mean(error_BF)  
        
    return err

def compute_optimal(x,y,err,df_cs,df_cm,df_bf,metric,hparams,device,space_i,names):
    """
    This function return the errors of CS/CM or bloom filters taking the optimal hyperparameters.
    Input parameters:
        - x: Data 
        - y: Mean of the data
        - err: Matrix where the errors of the different methods are going to be stored
        - df_cs,df_cm,df_bf: Dataframes with the best parameters for each alpha and beta
        - metric: Used to compute the errors
        - hparams: Parameters and hyperparameters of the models
        - device: Gpu
        - space_i: Iteration od alpha
        - names: Names of the models that are going to be evaluated
    Output parameters:
        - err: Matrix where the errors of the different methods are stored
    """
    # Define lists to store the result of each batch
    error_CM = []
    error_CS = []
    error_BF = []
    
    # Take the optimum d and w, for an specific alpha and beta
    if hparams['task'] == 'frequency_estimation': 
        countmin = SketchQueryalgorithms(hparams['n_dims'], int(df_cm.loc[space_i,'w']), int(df_cm.loc[space_i,'d']),'CM')
        countsketch = SketchQueryalgorithms(hparams['n_dims'],int(df_cs.loc[space_i,'w']), int(df_cs.loc[space_i,'d']),'CS')

        # For each batch
        for batch in range(x.shape[0]):
            x_i = x[batch].cpu()
            y_i = y[batch].cpu()
            
            # Compute CS
            y_hat, s = countsketch.SketchQuery_algorithms(x_i)
            error = torch.mean(metric(torch.clamp(y_hat, 0, 1)-y_i.squeeze()))
            error_CS.append(error.item()) 
            
            # Compute CM
            y_hat, s = countmin.SketchQuery_algorithms(x_i)
            error = torch.mean(metric(torch.clamp(y_hat, 0, 1)-y_i.squeeze()))
            error_CM.append(error.item()) 
        
        # Append the mean of the batches to the err matrix
        err[names.index('Count-Sketch (Optim)'),space_i] = np.mean(error_CS) 
        err[names.index('Count-Min (Optim)'),space_i] = np.mean(error_CM) 

        
    else:
        # Take the optimum d and w, for an specific alpha and beta
        bloom_filters = SketchQueryalgorithms(hparams['n_dims'],int(df_bf.loc[space_i,'w']), int(df_bf.loc[space_i,'d']),'BF')    
        # For each batch
        for batch in range(x.shape[0]):
            x_i = x[batch].cpu()
            y_i = y[batch].cpu()
            # Compute BF
            y_hat, s = bloom_filters.SketchQuery_algorithms(x_i)
            error = torch.mean(metric(torch.clamp(y_hat, 0, 1)-y_i.squeeze()))
            error_BF.append(error.item()) 
        
        # Append the mean of the batches to the err matrix
        err[names.index('Bloom-filter (Optim)'),space_i] = np.mean(error_BF) 
        
    return err

def compute_sqnet(x,y,err,metric,SN,QN,SN_rf,QN_rf,device,hparams,space_i,names):
    """
    This function computes the errors of the sqnet, rfqnet and with a dataset of all 0
    Input parameters:
        - x: Data 
        - y: Mean of the data
        - err: Matrix where the errors of the different methods are going to be stored
        - metric: Used to compute the errors
        - SN,QN,SN_rf,QN_rf: Trained networks
        - device: Gpu
        - hparams: Parameters and hyperparameters of the models
        - space_i: Iteration 
        - names: Names of the models that are going to be evaluated
    Output parameters:
        - err: Matrix where the errors of the different methods are stored
    """
    
    # Compute error of the data with all 0
    error = torch.mean(metric(0-y.squeeze()))
    err[names.index('All 0s'),space_i] = error.item()
    
    # If sqnet and rfnet 
    if hparams['both_sq_rfq']:
        with torch.no_grad():
            # SQNet
            sketch = SN(x, mean_dim=1,type_lastlayer=hparams['type_lastlayer_sq'],order_norm=hparams['order_norm_sq'])
            y_hat = torch.sigmoid(QN(sketch)).squeeze()
            error = torch.mean(metric(y_hat.cpu()-y.cpu()))
            err[names.index('SQNet'),space_i] = error.item()

        with torch.no_grad(): 
            # RFQnet
            sketch = SN_rf(x, mean_dim=1,type_lastlayer=hparams['type_lastlayer_rf'],order_norm=hparams['order_norm_rf'])
            y_hat = torch.sigmoid(QN_rf(sketch)).squeeze()
            error = torch.mean(metric(y_hat.cpu()-y.cpu()))
            err[names.index('RFQNet'),space_i] = error.item()
    # If just the sqnet or rfqnet need to be evaluated
    else:
        # SQNet
        if hparams['train_SN_QN']:
            with torch.no_grad():
                sketch = SN(x, mean_dim=1,type_lastlayer=hparams['type_lastlayer_sq'],order_norm=hparams['order_norm_sq'])
                y_hat = torch.sigmoid(QN(sketch)).squeeze()
                error = torch.mean(metric(y_hat.cpu()-y.cpu()))
                err[names.index('SQNet'),space_i] = error.item()
        # RFQNet
        else:
            with torch.no_grad(): 
                sketch = SN_rf(x, mean_dim=1,type_lastlayer=hparams['type_lastlayer_rf'],order_norm=hparams['order_norm_rf'])
                y_hat = torch.sigmoid(QN_rf(sketch)).squeeze()
                error = torch.mean(metric(y_hat.cpu()-y.cpu()))
                err[names.index('RFQNet'),space_i] = error.item()

        
    return err
    
     
def compute_errors(space,Beta,metric,err,hparams,SN,QN,SN_rf,QN_rf,device,df_cs,df_cm,df_bf,names):
    """
    This function computes the errors of the different methods based on the dataset.
    Input parameters:
        - space: List of alphas that are going to be used to create the dataframe
        - Beta: Beta that is going to be used to create the dataframe
        - metric: Used to compute the errors
        - err: Matrix where the errors of the different methods are going to be stored
        - hparams: Parameters and hyperparameters of the models
        - SN,QN,SN_rf,QN_rf: Trained networks
        - device: Gpu
        - df_cs,df_cm,df_bf: Dataframes with the best parameters for each alpha and beta
        - names: Names of the models that are going to be evaluated
    Output paratmeters:
        - err: Matrix where the errors of the different methods are stored
        - space: List of alphas that are going to be used to create the dataframe
    """
    
    ## SQNet vs CS vs CM Sketches
    # Computes the dataset with an specific Beta and different alphas
    num_samples = hparams['num_samples']
    # Indicates the iteration, in which alpha we are
    space_i = -1
    for alpha in space:
        space_i += 1
        # For each alpha and Beta define the dataset
        # membership estimation 500x10x1000 (batch x num_samples x num_dim)
        # frequency estimation 500x100x1000
        # Define class dataset
        zipfdatasetloader = ZipfOnlineDatasetLoader(hparams['batch_size'], hparams['n_dims'], hparams['num_samples'], alpha_min=alpha, alpha_max=alpha,beta_min=Beta, beta_max=Beta,device=device)
        for j, (x,y) in enumerate(zipfdatasetloader):
            if j == 0:
                
                if hparams['task'] == 'membership_estimation':
                    y[y == 0] = 0
                    y[y > 0] = 1     
                    
                # Compute CS/CM or Bf errors    
                err = compute_non_optimal(x,y,err,hparams,metric,device,space_i,names)
                
                # Compute CS/CM or Bf errors with the optimum hyperparameters
                err = compute_optimal(x,y,err,df_cs,df_cm,df_bf,metric,hparams,device,space_i,names)
                
                # Compute sqnet,rfnet and dataset with all 0 errors
                err = compute_sqnet(x,y,err,metric,SN,QN,SN_rf,QN_rf,device,hparams,space_i,names)

    return err,space


def read_optims(hparams,Beta):
    """
    Read the files where there are stores the best parameters for each alpha and beta. This files are created in the scripts bestparameters_BF.py and bestparameters_CM_CS.py
    The input parameters are the parameters and hyperparameters of the models, and the corresponding beta.
    The alphas selected are the ones found in the files.
    The output are the dataframes with the best parameters for each alpha and beta
    """
    # Read df_cm and df_cs
    if hparams['task'] == 'frequency_estimation':
        df_cm = pd.read_csv(hparams['path_opt_CM']) 
        df_cs = pd.read_csv(hparams['path_opt_CS']) 
        if Beta == 0.5:
            Beta = df_cm['beta'].unique()[2]
        df_cm = df_cm[df_cm['beta']==Beta]
        df_cs = df_cs[df_cs['beta']==Beta]
        space = list(df_cm['alpha'].unique())

        # Reset indexes
        df_cs = df_cs.reset_index()
        df_cm = df_cm.reset_index()    

        df_bf = []

    # Read df_bf
    else:
        df_bf = pd.read_csv(hparams['path_opt_BF'])
        df_bf = df_bf[df_bf['beta']==Beta]
        df_bf = df_bf.reset_index()  
        space = list(df_bf['alpha'].unique())
        df_cs = []
        df_cm = []    
        

    return df_cs,df_cm,df_bf,space
    
        
def compute_test(SN,QN,hparams,device,SN_rf,QN_rf):
    """
    This function test the different methods to compute the corresponding task with Beta 0.5 (membership estimation task), and 1 (frequency estimation task), and plots the result. 
    The objective is to evaluate the different methods.
    The inputs parameters are the trained networks, the parameters and hyperparameters of the models, and the device
    The output are two plots with different zoom
    """
    # Defines the beta
    if hparams['task']=='frequency_estimation':
        beta = [1.0]
    else:
        beta = [0.5]
    
    for Beta in beta:
        
        # Read the file that have the optimum d and w for CS/CM or BF
        df_cs,df_cm,df_bf,space = read_optims(hparams,Beta)
        
        # Define the errors, colors, and names vector depending on the methods we want to evaluate
        # Frequency task
        if hparams['task']=='frequency_estimation':
            if hparams['both_sq_rfq']:
                # 7: CM/CS/CM_opt/CS_opt/sqnet/rfnet/error_0
                err = np.zeros([7,len(space)])
                names = ['CS','Count-Sketch (Optim)','CM','Count-Min (Optim)','SQNet','RFQNet','All 0s']
                colors = ['pink','pink','deepskyblue','deepskyblue','red','darkred','orange']
            else:
                # 6: CM/CS/CM_opt/CS_opt/sqnet or rfnet/error_0
                err = np.zeros([6,len(space)])
                # 6: CM/CS/CM_opt/CS_opt/sqnet/error_0
                if hparams['train_SN_QN']:
                    names = ['CS','Count-Sketch (Optim)','CM','Count-Min (Optim)','SQNet','All 0s']
                    colors = ['pink','pink','deepskyblue','deepskyblue','red','orange']
                # 6: CM/CS/CM_opt/CS_opt/rfnet/error_0
                else:
                    names = ['CS','Count-Sketch (Optim)','CM','Count-Min (Optim)','RFQNet','All 0s']
                    colors = ['pink','pink','deepskyblue','deepskyblue','darkred','orange']
        # Membership task
        else:
            if hparams['both_sq_rfq']:
                # 5: BF/BF_opt/sqnet/rfnet/error_0
                err = np.zeros([5,len(space)])
                names = ['BF','Bloom-filter (Optim)','SQNet','RFQNet','All 0s']
                colors = ['deepskyblue','deepskyblue','red','darkred','orange']
            else:
                # 4: BF/BF_opt/sqnet or rfnet/error_0
                err = np.zeros([4,len(space)])
                # 4: BF/BF_opt/sqnet/error_0
                if hparams['train_SN_QN']:
                    names = ['BF','Bloom-filter (Optim)','SQNet','All 0s']
                    colors = ['deepskyblue','deepskyblue','red','orange']
                 # 4: BF/BF_opt/rfnet/error_0
                else:
                    names = ['BF','Bloom-filter (Optim)','RFQNet','All 0s']
                    colors = ['deepskyblue','deepskyblue','darkred','orange']
                
        
        # Define the metric to compute the errors
        metric = torch.square #torch.abs #torch.square
        
        # Compute the errors
        err,space = compute_errors(space,Beta,metric,err,hparams,SN,QN,SN_rf,QN_rf,device,df_cs,df_cm,df_bf,names)
        
        # Compute plots
        compute_plot_zoomalpha(err,names,colors,space,Beta,hparams)
        compute_plot_zoomMSE(err,names,colors,space,Beta,hparams)


        
        

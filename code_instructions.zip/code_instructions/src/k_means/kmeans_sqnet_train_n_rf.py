print('Start importing required libraries...')
import os, sys, time
sys.path.append('../')
sys.path.append('../../')
#import tqdm
from tqdm.auto import tqdm
import allel
import yaml
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
torch.autograd.set_detect_anomaly(True)
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math

import higher

from collections import Counter
import gzip
from scipy.interpolate import interp1d

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
from torch import nn, optim
from torch.autograd import Function
import time
import importlib
import itertools  
import math
from IPython.display import display

from torchvision import datasets, transforms
    
from sklearn.decomposition import PCA
import umap

# from diffoptim.safeoptim import DifferentiableAdamSafe

# higher.register_optim(torch.optim.AdamW, DifferentiableAdamSafe)

from network.layers import Clamp01, Cosine, Square, Scale, MultiActivation, UAF, CosineSine, Normalize
from network.models import SketchNetwork, SketchNetworkResLN, RandomFeatures, SimulateInput
print('done')



finetune = True

device = 'cuda:6'
eps = 1e-5
# activation = torch.sigmoid
#activation = nn.Identity()
activation = Clamp01()
# activation = nn.Hardsigmoid()
#activation = nn.Sigmoid()


transform = transforms.Compose([transforms.ToTensor(),
                              #transforms.Normalize((0.5,), (0.5,)),
                              ])
trainset = datasets.MNIST(download=True, train=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=2048*999, shuffle=True)




for _, data in enumerate(trainloader, 0):
    all_inputs_total, all_labels_total = data
    all_inputs, all_labels = all_inputs_total[0::2,...], all_labels_total[0::2]
    all_inputs_test, all_labels_test = all_inputs_total[1::2,...], all_labels_total[1::2]
    break 

# for _, data in enumerate(testloader, 0):
#     all_inputs_test, all_labels_test = data
#     break  

print(all_inputs.shape)


## TEST DATASET

numbers_to_keep = [0,1,8]
#numbers_to_keep = [0,1,8,5,7]

subsets = []
labels_subsets = []
for i, n in enumerate(numbers_to_keep):
    subsets.append(all_inputs_test[all_labels_test==n,...])
    labels_subsets.append(torch.ones(all_inputs_test[all_labels_test==n,...].shape[0])*i)

inputs_test = torch.cat(subsets)
labels_test = torch.cat(labels_subsets)


# Flatten dataset    
inputs_test = inputs_test.squeeze().flatten(start_dim=1) #

inputs_test = inputs_test[0::4,:]#.to(device)
labels_test = labels_test[0::4]#.to(device)


import random



def kmeans_loss(prediction, target):
    sim_input = prediction
    inputs = target
    a = activation(sim_input).unsqueeze(1)
    b = inputs.unsqueeze(1).unsqueeze(0)
    diff = torch.square(a - b)
    diff = torch.mean(diff, dim=3)
    diff_min, _ = torch.min(diff, dim=2)
    loss = torch.mean(diff_min)
    return loss

def train_higher(SN, input_dim, sketch_dim, testing_dataset, data_augmentation=True, train_in_test=False, lr_training=0.00001, n_batch = 8, n_samples_si = 3, lr_si=0.1, max_num_iter_si=1000, sn_ratio=10, rf_ratio=500, random_rf_dim=True):
    print('init func')
    
    SI = SimulateInput(SN, 'AdamW',  activation, n_batch=n_batch, n_seq=n_samples_si, n_inner_iter=max_num_iter_si, input_dim=input_dim, lr=lr_si, track_higher_grads=True).to(device)
    
    
    optimizer = optim.Adam(SN.parameters(), lr=lr_training, weight_decay=0.0001)
    #optimizer = optim.Adam([*scale.parameters(), *act.parameters()], lr=lr, weight_decay=0.0)
    
    num_max_iters = 20000
    
    if max_num_iter_si < 0:
        random_max_num_iter_si = True
    
    for i in range(num_max_iters):
      
        k = torch.randint(low=2,high=10,size=(1,))
        SI.n_seq = k
        
        if random_max_num_iter_si:
            if i < 6000:
                it = torch.randint(low=2,high=50,size=(1,))
            else:
                it = torch.randint(low=2,high=70,size=(1,))
            #it = torch.randint(low=2,high=75,size=(1,))
            SI.n_inner_iter = it
            
        if random_rf_dim:
            if torch.rand(1) > 0.5:
                sn_ratio_test = torch.randint(low=1,high=20,size=(1,))
            else:
                sn_ratio_test = 20
            SI.sketch_dim_to_use = input_dim*sn_ratio_test
        
        if not train_in_test:
            # Get random dataset MNIST
            #all_numbers_to_keep = [2,3,4, 5, 6, 7, 9]
            rand_idx = torch.randperm(all_inputs.shape[0])
            all_numbers_to_keep = [0,1,2,3,4, 5, 6, 7, 8,9]
            numbers_to_keep = random.sample(all_numbers_to_keep, k)
            subsets = []
            labels_subsets = []
            for j, n in enumerate(numbers_to_keep):
                subsets.append(all_inputs[rand_idx,...][all_labels==n,...][0::10,...])
            inputs = torch.cat(subsets)
            
            if data_augmentation:
                if torch.rand(1) > 0.5:
                    inputs = torch.flip(inputs, [2,3])
                if torch.rand(1) > 0.5:
                    n_rot = int(torch.randint(low=1,high=4,size=(1,)))
                    inputs = torch.rot90(inputs, n_rot, [2,3])  


            inputs = inputs.squeeze().flatten(start_dim=1) #
        
        else:
            inputs = testing_dataset
        
        
        inputs = inputs.to(device)
        
        #print(inputs.shape)

        optimizer.zero_grad()
        
        sketch_sn = torch.mean(SN(inputs), dim=0).to(device)
        
        sim_input =  SI(sketch_sn)
        
        # Compute k-means loss        
        loss = kmeans_loss(sim_input, inputs)
        
        loss.backward()
        optimizer.step()
        
        if i % 20 == 0:
            print('Iter {} with loss {}'.format(i, loss.item()))
            
        if i % 1000 == 0:
            print('Storing network --- Iter {} with loss {}'.format(i, loss.item()))
            output_path = '' # to include
            sketch_path = output_path
            torch.save(SN.state_dict(), sketch_path)
            


        
    return SI


input_dim = all_inputs.shape[2]*all_inputs.shape[3]

# 1 and 2 ---> all Ks



output_path = ''

results = []

#for sn_ratio in list(range(1,21,1))[::-1]:
for output_activation in [nn.GELU()]:
    for lr_si in [0.5]:#[0.5, 1.0]:#[0.1, 0.5, 1.0]:
        for lr_training in [0.00001]: #[0.001, 0.0001]
            for sn_ratio in [20]:#list([1,2,3,4,5,7,9,10,15,20])[::-1]:
                for steps_train in list([-1])[::-1]:#[1,2,5,10,50,100,200,500]:
                
                    print('start training with...', sn_ratio, output_activation, lr_training, steps_train, lr_si)
                    sketch_dim = input_dim*sn_ratio
                    SN = SketchNetworkResLN(input_dim, sketch_dim, num_hidden=4, output_activation=output_activation).to(device)
                    

                    
                    SI = train_higher(SN, input_dim, sketch_dim, inputs_test, train_in_test=False, lr_training=lr_training, n_batch = 16, n_samples_si = 7, lr_si=lr_si, max_num_iter_si=steps_train, sn_ratio=sn_ratio, rf_ratio=1, )

                    print('done with...', sn_ratio, output_activation, lr_training, steps_train, lr_si)

                    # Evalutaion
                    inputs_test = inputs_test.to(device)
                    sketch_sn = torch.mean(SI.SketchNet(inputs_test), dim=0).to(device)

                    SI.n_seq = 3
                    for sn_ratio_test in [1,2,3,4,5,7,9,10,15,20]:
                    #SI.n_inner_iter = 10
                        SI.sketch_dim_to_use = input_dim*sn_ratio_test
                        
                        for steps in list([1,2,5,10,50,100,200,500])[::-1]:
                            SI.n_inner_iter = steps
                            SI.track_higher_grads = False
                            sim_input =  SI(sketch_sn)
                            SI.track_higher_grads = True

                            error = kmeans_loss(sim_input, inputs_test)
                            error = error.detach().cpu().numpy()

                            results.append({
                                'mse_mean' : error,
                                'mse_std' : 0,
                                'num_iters': steps,
                                'num_iters_train': steps_train,
                                'n_rf' : sn_ratio,
                                'lr': lr_si,
                                'rf_activation': str(output_activation),
                                'lr_training' : lr_training
                                })
                            print('steps / error is: ' , steps, error)
                        pd.DataFrame(results).to_pickle(output_path)  

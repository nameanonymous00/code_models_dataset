import torch
torch.autograd.set_detect_anomaly(True)
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


class Clamp01(torch.nn.Module):

    def __init__(self):
        super().__init__()
             
    def forward(self, x):
        return torch.clamp(x,0,1)
    
    
class Cosine(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return torch.cos(x)

class Normalize(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return x / torch.sqrt(torch.sum(torch.square(x),dim=-1, keepdim=True))
    
class Sine(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return torch.sin(x)
    
    
class CosineSine(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return torch.cat([torch.cos(x), torch.sin(x)], dim=-1)

    
class Square(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return torch.square(x)

class Scale(torch.nn.Module):

    def __init__(self, init_scale=0.2):
        super().__init__()
        self.scale = nn.Parameter(torch.log(torch.tensor(init_scale, requires_grad=True)))
                 
    def forward(self, x):
        return x*torch.exp(self.scale)

class MultiActivation(nn.Module):
    def __init__(self):
        super().__init__()
        self.activations = nn.ModuleList(
            [nn.ReLU(),
             nn.GELU(),
             nn.Tanh(),
             Cosine(),
             Square(),
             nn.Identity()
            ])
        self.scales = nn.Parameter(torch.randn((len(self.activations),), requires_grad=True)*0.1)

                 
    def forward(self, x):
        scales = F.softmax(self.scales, dim=0)
        outs = []
        for i, act in enumerate(self.activations):
            outs.append(act(x)*scales[i])
        outs = torch.stack(outs)
        outs = torch.sum(outs, dim=0)
        #print('outs shape is',outs.shape)
        return outs


    
    
    
class ResidualFCLN(torch.nn.Module):
    def __init__(self, hidden_dim, bottleneck_dim=None):
        super().__init__()
        
        if bottleneck_dim == None:
            bottleneck_dim = hidden_dim
        
        self.layers = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            
        )        
                
    def forward(self, x):
        y = self.layers(x) + x
        return y
import torch
torch.autograd.set_detect_anomaly(True)
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math

import higher
from .safeoptim import DifferentiableAdamSafe
from .layers import Clamp01, Cosine, Square, Scale, MultiActivation, UAF, CosineSine, Sine, ResidualFCLN

higher.register_optim(torch.optim.AdamW, DifferentiableAdamSafe)


class SketchNetwork(torch.nn.Module):

    def __init__(self,in_dim,out_dim, expansion_ratio=2, num_hidden=1, output_activation=nn.LeakyReLU()):
        super().__init__()
        
        hidden = []
        for _ in range(num_hidden):
            hidden.extend([nn.Linear(in_dim*expansion_ratio, in_dim*expansion_ratio), nn.GELU()])
        
        self.net = nn.Sequential(
            nn.Linear(in_dim, in_dim*expansion_ratio),
            nn.GELU(),
            *hidden,
            nn.Linear(in_dim*expansion_ratio, out_dim),
            output_activation
        )        
                
    def forward(self, x):
        y = self.net(x)
        return y
    

class SketchNetworkResLN(torch.nn.Module):

    def __init__(self,in_dim,out_dim, expansion_ratio=2, num_hidden=3, output_activation=nn.GELU()):
        super().__init__()
        
        hidden = []
        for _ in range(num_hidden):
            hidden.extend([ResidualFCLN(in_dim*expansion_ratio)])
        
        self.net = nn.Sequential(
            nn.Linear(in_dim, in_dim*expansion_ratio),
            *hidden,
            nn.Linear(in_dim*expansion_ratio, out_dim),
            output_activation
        )        
                
    def forward(self, x):
        y = self.net(x)
        return y

    
class RandomFeatures(torch.nn.Module):

    def __init__(self,in_dim,out_dim, activation='relu', var=1.0):
        super().__init__()
        
        if activation == 'relu':
            act = nn.ReLU()
        elif activation == 'lrelu':
            act = nn.LeakyReLU()
        elif activation == 'gelu':
            act = nn.GELU()
        elif activation == 'tanh':
            act = nn.Tanh()
        elif activation == 'sigmoid':
            act = nn.Sigmoid()
        elif activation == 'square':
            act = Square()
        elif activation == 'cos' or activation == 'cosine':
            act = Cosine()
        elif activation == 'sin' or activation == 'sine':
            act = Sine()
        elif activation == 'rff' or activation == 'fourier' or activation == 'cosine-sine' or activation == 'cos-sin':
            act = CosineSine()
            out_dim = max(int(out_dim / 2),1)
            
        self.net = nn.Sequential(
            nn.Linear(in_dim, out_dim, bias=False),
            act
        )
        
        self.net[0].weight.data = torch.randn(self.net[0].weight.data.shape)*var
                
    def forward(self, x):

        y = self.net(x)
        return y
    
    
    
class SimulateInput(nn.Module):
    """TODO
    Args:
        TODO
    """
    def __init__(self, Snet, optimizer, activation_simulation, n_batch: int = 32, n_seq: int = 20, n_inner_iter: int = 1000, input_dim: int = 100, lr: float = 0.1, track_higher_grads: bool = True):
        super(SimulateInput, self).__init__()
        self.SketchNet = Snet
        self.n_seq = n_seq
        self.n_batch = n_batch
        self.n_inner_iter = n_inner_iter
        self.input_dim = input_dim
        self.lr = lr
        self.optimizer = optimizer
        self.activation_simulation = activation_simulation
        self.track_higher_grads = track_higher_grads
        self.sketch_dim_to_use = -1

    def forward(self, s):
        
        if len(s.shape) == 1:
            s = s.unsqueeze(0)

        # Make an initial guess of the labels.
        # For more sophisticated tasks this could also be learned.
        #y = torch.randn(self.n_seq, self.input_dim, device=s.device, requires_grad=True)
        
        #init = torch.randn((int(self.n_batch), int(self.n_seq), int(self.input_dim)), requires_grad=True, device=s.device)*1.0
        init = torch.rand((int(self.n_batch), int(self.n_seq), int(self.input_dim)), requires_grad=True, device=s.device)#*0.01+0.45
        y = nn.Parameter(init).to(s.device)
        #print('y shape is', y.shape)

        # Define a differentiable optimizer to update the label with.
        if self.optimizer == 'Adam':
            optim =  torch.optim.Adam([y], lr=self.lr, eps=1e-06, weight_decay=0.0)
        elif self.optimizer == 'AdamW':
            optim =  torch.optim.AdamW([y], lr=self.lr, eps=1e-06, weight_decay=0.0)
            #optim =  higher.optim.DifferentiableAdam([y], lr=self.lr, eps=1e-06, weight_decay=0.0)
        elif self.optimizer == 'Adagrad':
            optim =  torch.optim.Adagrad([y], lr=self.lr, eps=1e-06, weight_decay=0.0)
        elif self.optimizer == 'Adamax':
            optim =  torch.optim.Adamax([y], lr=self.lr, eps=1e-06, weight_decay=0.0)

        elif self.optimizer == 'SGD':
            optim =  torch.optim.SGD([y], lr=self.lr, weight_decay=0.0)
                
        inner_opt = higher.get_diff_optim(
            optim,
            [y], device=s.device
        )
        
        inner_opt.track_higher_grads = self.track_higher_grads

        #y = y*0.001
        # Take a few gradient steps to find the labels that
        # optimize the energy function.
        # y_old = y
        for _ in range(self.n_inner_iter):
            s_hat = self.SketchNet(self.activation_simulation(y)).mean(dim=1)
            #print('shapes are', s_hat.shape, s.shape)
            d = self.sketch_dim_to_use
            loss = ((s_hat[:,0:d] - s[:,0:d])**2).mean()
            y, = inner_opt.step(loss, params=[y])
            #y = torch.clamp(y,0,1)
            y = self.activation_simulation(y)
            #print('y shape is', y.shape)
            # print('diff is, ', torch.sum((y-y_old)**2))
            # y_old = y

        return y
    

# https://github.com/facebookresearch/higher/issues/125
print('Start importing required libraries...')
import os, sys, time
sys.path.append('../')
sys.path.append('../../')
#import tqdm
from tqdm.auto import tqdm
import allel
import yaml
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
torch.autograd.set_detect_anomaly(True)
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math

from collections import Counter
import gzip
from scipy.interpolate import interp1d

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
from torch import nn, optim
from torch.autograd import Function
import time
import importlib
import itertools  
import math
from IPython.display import display

from torchvision import datasets, transforms
    
from sklearn.decomposition import PCA
import umap
import higher



from network.layers import Clamp01, Cosine, Square, Scale, MultiActivation, UAF, CosineSine, Normalize
from network.models import SketchNetwork, SketchNetworkResLN, RandomFeatures, SimulateInput
print('done')


device = 'cuda:1'
eps = 1e-5
# activation = torch.sigmoid
#activation = nn.Identity()
activation = Clamp01()
# activation = nn.Hardsigmoid()
#activation = nn.Sigmoid()


def imshow(img):
    if len(img.shape) < 3:
        img = img.view(1,28,28)
    img = img / 2 + 0.5     # unnormalize
    npimg = img.detach().cpu().numpy()
    plt.imshow(np.transpose(npimg, (1, 2, 0)))
    plt.show()
    
    
    
transform = transforms.Compose([transforms.ToTensor(),
                              #transforms.Normalize((0.5,), (0.5,)),
                              ])
trainset = datasets.MNIST(download=True, train=False, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=2048*999, shuffle=False)

for _, data in enumerate(trainloader, 0):
    all_inputs, all_labels = data
    break    

print(all_inputs.shape)
# Plotting some example
imshow(all_inputs[0,...])




#numbers_to_keep = [0,1,8]
numbers_to_keep = [0,1,8, 2, 5]
#numbers_to_keep = [0,1,2,3,4,5,6,7,8,9]
K = len(numbers_to_keep)

subsets = []
labels_subsets = []
for i, n in enumerate(numbers_to_keep):
    subsets.append(all_inputs[all_labels==n,...])
    labels_subsets.append(torch.ones(all_inputs[all_labels==n,...].shape[0])*i)
    
inputs = torch.cat(subsets)
labels = torch.cat(labels_subsets)


# Flatten dataset    
inputs = inputs.squeeze().flatten(start_dim=1) #

inputs = inputs[0::4,:].to(device)
labels = labels[0::4]#.to(device)

input_dim = 784
# Normalize
# inputs_ten_mean = torch.mean(inputs_ten, dim=0)
# inputs_ten_var = torch.std(inputs_ten, dim=0) 
# # inputs_ten_var[inputs_ten_var==0]=1
# # inputs_ten_var +=  eps
# inputs_ten_var +=  1
# inputs_ten = (inputs_ten - inputs_ten_mean) / inputs_ten_var





print('shape here is', inputs.shape)

# Plotting PCA
pca = PCA(n_components=2)
pcs = pca.fit_transform(inputs.cpu().numpy())






def simulate_and_plot_rf_higher(inputs, device, SI, activation=Clamp01(),rf_activation='tanh', var=0.1, n_batch = 5, n_samples = 30, lr=0.1, sn_ratio=500, max_num_iter=15000, do_plot=False, verbose=False):
    


    with torch.no_grad():
        sketch = torch.mean(SI.SketchNet(inputs), dim=0).to(device)
        #print(sketch.shape)

    if verbose:
        print('start to run')
    
    sim_input =  SI(sketch.unsqueeze(0))
    
    if verbose:
        print('sim input shape is', sim_input.shape)
        print('done running')
    
    
    
    with torch.no_grad():
        a = activation(sim_input).unsqueeze(1)
        b = inputs.unsqueeze(1).unsqueeze(0)
        diff = torch.square(a - b)
        diff = torch.mean(diff, dim=3)
        diff_min, _ = torch.min(diff, dim=2)
        #print(diff_min.shape, 'shape is')
        mses = torch.mean(diff_min, dim=1)
        mse = torch.mean(mses)
        if verbose:
            print('MSE IS ', mse.item())
    
    
    sim_input = sim_input[0,:,:]
    
    if do_plot:
        with torch.no_grad():
            pcs_new = pca.transform(activation(sim_input).detach().cpu().numpy())
            fig = plt.figure(figsize=(10,8))
            plt.scatter(pcs[:,0], pcs[:,1],  c=labels, s=2)
            plt.scatter(pcs_new[:,0], pcs_new[:,1],  c='r', s=20)
            plt.show()


            # After training plot the centroids as images 
            centroids = activation(sim_input).detach().cpu().numpy()
            pcs_new = pca.transform(centroids)
            fig = plt.figure(figsize=(10,8))
            plt.scatter(pcs[:,0], pcs[:,1],  c=labels, s=2)
            plt.scatter(pcs_new[:,0], pcs_new[:,1],  c='r', s=20)
            plt.show()

            for i in range(centroids.shape[0]):
                imshow(torch.tensor(centroids[i,...]))
            
    return mses, mse
        


rf_path = ''
hparams_rf_all = pd.read_pickle(rf_path)


n_runs = 5
n_batch = 8

output_path = ''

results = []


network_path = ''



# for rf_activation in ['rff', 'sin', 'cos', 'square', 'tanh', 'sigmoid', 'gelu', 'lrelu',  'relu' ]:

rf_activation = 'Network'

for rf_activation in ['Network']: #['tanh', 'gelu', 'relu', 'Network',  'square', 'rff' ]:
    for num_iters in list([1,2,5,10,50,100, 200, 500])[::-1]:  #[1,2,5,10,50,100,200,500]
        for n in range(1,21,1):
            print('running ... ', num_iters, rf_activation, n)
            mses_list = []
            
            if rf_activation == 'Network':
                SN = SketchNetworkResLN(input_dim, input_dim*20, num_hidden=4, output_activation=nn.GELU()).to(device)
                SN.load_state_dict(torch.load(network_path, map_location=device))
                SI = SimulateInput(SN, 'AdamW', activation, n_batch=n_batch, n_seq= K, n_inner_iter=-1, input_dim=inputs.shape[1], lr=0.5, track_higher_grads=False).to(device)
                
            else:
                hparams = hparams_rf_all[hparams_rf_all['rf_activation'] == rf_activation]
                hparams = hparams[hparams['num_iters'] == num_iters]
                hparams = hparams[hparams['n_rf'] == n]
                ms = np.array(hparams['mse_mean'])
                idx_min = np.argmin(ms)
                #hparams = 
                var = np.array(hparams['var'])[idx_min]
                lr = np.array(hparams['lr'])[idx_min]
                print('var and lr are...', var, lr)
                SN = RandomFeatures(inputs.shape[1], int(n*inputs.shape[1]), activation=rf_activation, var=var).to(device)
                SI = SimulateInput(SN, 'Adam', activation, n_batch=n_batch, n_seq= K, n_inner_iter=-1, input_dim=inputs.shape[1], lr=lr, track_higher_grads=False).to(device)

            SN.eval()
            SI.eval()
            
            SI.n_inner_iter = num_iters
            SI.sketch_dim_to_use = input_dim*n
            
            for _ in range(n_runs):
                
                if rf_activation != 'Network':
                    SI.SketchNet.net[0].weight.data = torch.randn_like(SI.SketchNet.net[0].weight.data)*var
                
                mses, _ = simulate_and_plot_rf_higher(inputs, device, SI, rf_activation=rf_activation, n_batch = n_batch, n_samples = K, lr=0.5, sn_ratio=n, max_num_iter=num_iters, do_plot=False, verbose=False)
                mses_list.append(mses.cpu().detach().numpy())
            print('mean std is', np.mean(mses_list), np.std(mses_list))
            results.append({
                'mse_mean' : np.mean(mses_list),
                'mse_std' : np.std(mses_list),
                'num_iters': num_iters,
                'n_rf' : n,
                'rf_activation': rf_activation
                })
            pd.DataFrame(results).to_pickle(output_path)  


# plt.plot(mse_list)
# plt.show()

results = pd.DataFrame(results)
results.to_pickle(output_path) 
#results = results.sort_values(by='mse', ascending=True)
print(results)
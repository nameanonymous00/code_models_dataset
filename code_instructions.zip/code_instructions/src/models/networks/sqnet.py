import torch
import torch.nn as nn
from .layers.residual import ResidualFCwithPermute, ResidualFC
from .layers.permute import Permute

class SketchNetwork(torch.nn.Module):

    def __init__(self,in_dim,out_dim,hidden_dim):
        super().__init__()
        
        hidden_dim = in_dim*2
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            Permute((0,2,1)),
            nn.BatchNorm1d(hidden_dim),
            Permute((0,2,1)),
            ResidualFCwithPermute(hidden_dim),
            ResidualFCwithPermute(hidden_dim),
            ResidualFCwithPermute(hidden_dim),
            nn.Linear(hidden_dim, out_dim),
        )        
                
    def forward(self, x, mean_dim=None,type_lastlayer='Mean',order_norm=2):
        y = self.net(x)
        if mean_dim != None:
            #  Min, Max, Log-sum-exp, p-norm, -1*log-sum-exp(-x), -1*p-norm(-x)
            if type_lastlayer == 'Mean':
                y = torch.mean(y, dim=mean_dim)
            elif type_lastlayer == 'Min':
                y = torch.min(y, dim=mean_dim).values
            elif type_lastlayer == 'Max':
                y = torch.max(y, dim=mean_dim).values
            elif type_lastlayer == 'Log-sum-exp':    
                y = torch.logsumexp(y, dim=mean_dim)
            elif type_lastlayer == 'p-norm':   
                y = torch.linalg.norm(y,ord=order_norm, dim=mean_dim)
            elif type_lastlayer == '-1*log-sum-exp(-x)':  
                y = -1 * torch.logsumexp(-y, dim=mean_dim)
            elif type_lastlayer == '-1*p-norm(-x)':
                y = -1 * torch.linalg.norm(-y,ord=order_norm, dim=mean_dim) 
        return y

    
class QueryNetworkTask(torch.nn.Module):

    def __init__(self, in_dim, out_dim,hidden_dim):
        super().__init__()
        
        hidden_dim = out_dim*2
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.BatchNorm1d(hidden_dim),
            ResidualFC(hidden_dim),
            ResidualFC(hidden_dim),
            ResidualFC(hidden_dim),
            nn.Linear(hidden_dim, out_dim),
        )        
                
    def forward(self, x):
        y = self.net(x)
        return y
    

class RandomFeatures(torch.nn.Module):

    def __init__(self,in_dim,out_dim, activation='relu', var=1.0):
        super().__init__()
        if activation == 'relu':
            act = nn.ReLU()
        elif activation == 'lrelu':
            act = nn.LeakyReLU()
        elif activation == 'gelu': 
            act = nn.GELU()
        elif activation == 'tanh':
            act = nn.Tanh()
        elif activation == 'sigmoid':
            act = nn.Sigmoid()
        elif activation == 'square':
            act = Square()
        elif activation == 'cos' or activation == 'cosine':
            act = Cosine()
        elif activation == 'sin' or activation == 'sine':
            act = Sine()
        elif activation == 'rff' or activation == 'fourier' or activation == 'cosine-sine' or activation == 'cos-sin':
            act = CosineSine()
            out_dim = max(int(out_dim / 2),1)
            
        self.net = nn.Sequential(
            nn.Linear(in_dim, out_dim, bias=False),
            act
        )
        
        self.net[0].weight.data = torch.randn(self.net[0].weight.data.shape)*var
                
    def forward(self, x,mean_dim=None,type_lastlayer='Mean',order_norm=2):
        y = self.net(x)
        if mean_dim != None:
            y = torch.mean(y, dim=mean_dim)         

        return y
    
class Cosine(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return torch.cos(x)
    
    
class Sine(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return torch.sin(x)
    
    
class CosineSine(torch.nn.Module):

    def __init__(self):
        super().__init__()
                 
    def forward(self, x):
        return torch.cat([torch.cos(x), torch.sin(x)], dim=-1)
    
    
    
    
class SketchNetworkResLN(torch.nn.Module):

    def __init__(self,in_dim,out_dim, expansion_ratio=2, num_hidden=3, output_activation=nn.GELU()):
        super().__init__()
        
        hidden = []
        for _ in range(num_hidden):
            hidden.extend([ResidualFCLN(in_dim*expansion_ratio)])
        
        self.net = nn.Sequential(
            nn.Linear(in_dim, in_dim*expansion_ratio),
            *hidden,
            nn.Linear(in_dim*expansion_ratio, out_dim),
            output_activation
        )        
                
    def forward(self, x, mean_dim=None,type_lastlayer='Mean',order_norm=2):
        y = self.net(x)
        if mean_dim != None:
            #  Min, Max, Log-sum-exp, p-norm, -1*log-sum-exp(-x), -1*p-norm(-x)
            if type_lastlayer == 'Mean':
                y = torch.mean(y, dim=mean_dim)
            elif type_lastlayer == 'Min':
                y = torch.min(y, dim=mean_dim).values
            elif type_lastlayer == 'Max':
                y = torch.max(y, dim=mean_dim).values
            elif type_lastlayer == 'Log-sum-exp':    
                y = torch.logsumexp(y, dim=mean_dim)
            elif type_lastlayer == 'p-norm':   
                y = torch.linalg.norm(y,ord=order_norm, dim=mean_dim)
            elif type_lastlayer == '-1*log-sum-exp(-x)':  
                y = -1 * torch.logsumexp(-y, dim=mean_dim)
            elif type_lastlayer == '-1*p-norm(-x)':
                y = -1 * torch.linalg.norm(-y,ord=order_norm, dim=mean_dim)   
                
        return y
    

class ResidualFCLN(torch.nn.Module):
    def __init__(self, hidden_dim, bottleneck_dim=None):
        super().__init__()
        
        if bottleneck_dim == None:
            bottleneck_dim = hidden_dim
        
        self.layers = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            
        )        
                
    def forward(self, x):
        y = self.layers(x) + x
        return y
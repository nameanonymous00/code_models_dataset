import torch
import torch.nn as nn
import torch.nn.functional as F
from .permute import Permute

class ResidualFC(torch.nn.Module):
    def __init__(self, hidden_dim):
        super().__init__()
        
        self.layers = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.BatchNorm1d(hidden_dim),
        )        
                
    def forward(self, x):
        y = self.layers(x) + x
        return y
    
    
class ResidualFCwithPermute(torch.nn.Module):
    def __init__(self, hidden_dim):
        super().__init__()
        
        self.layers = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            Permute((0,2,1)),
            nn.BatchNorm1d(hidden_dim),
            Permute((0,2,1)),
        )        
                
    def forward(self, x):
        y = self.layers(x) + x
        return y
import torch
import torch.nn as nn


class Permute(nn.Module):
    def __init__(self, permute):
        super().__init__()
        self.permute = permute

    def forward(self, x):
        return x.permute(self.permute)

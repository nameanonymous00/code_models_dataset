import torch
import numpy as np

class SketchQueryalgorithms():
    """
    This class computes the count sketch (CS), count min sketch (CM) or bloom filter(BF) algorithms. 
    Input:
        - n_dims: Number of features
        - w: Dimension of the projection
        - d: Number of linear projections
        - method: CS (count sketch) , CM (count min sketch) or BF (bloom filter)
        - x: data. The support it dimensions are: 
            input: D --> output: D  
            input: N x D --> output: D 
            input: B x N x D ---> output: D  
    Output:
        - If method is CS o CM: Frequency of the features of the dataset
        - If method is BF: One hot vector indicating if the feature is present or not
    """

    def __init__(self,n_dims, w, d, method):
        super().__init__()

        W_list = []
        for i in range(d):
            W = torch.zeros(n_dims, w).float()
            for j in range(n_dims):
                k = torch.randint(high=w, size=(1,))
                if method == 'CS':
                    W[j,k] = 1 * torch.sign(torch.randn(1))
                else: # CM, BF
                    W[j,k] = 1
            W_list.append(torch.nn.Parameter(W))
        
        self.ws = torch.nn.ParameterList(W_list)
        self.mean_mode = 'before'
        self.do_clamp = True
        self.method = method
        

    def sketch(self, x):
        if (len(x.shape) == 2) and (self.mean_mode == 'before'):
            x = torch.mean(x, dim=0)
        
        outs = []
        for W in self.ws:
            out = torch.matmul(x, W)
            outs.append(out)
        s = torch.stack(outs, dim=0)
        
        if (len(x.shape) == 2) and (self.mean_mode == 'after'):
            s = torch.mean(s, dim=1)

        # BF
        if self.method == 'BF':
            s[s == 0] = 0
            s[s > 0] = 1
            
        return s
        
    def query(self, s):
        recs = []
        for i, W in enumerate(self.ws):
            rec = torch.matmul(s[i,:],W.T)
            recs.append(rec)
        recs = torch.stack(recs, dim=0)

        if self.method == 'CS':
            x_hat, _ = torch.median(recs, dim=0)
        else: # If CM or BF
            x_hat, _ = torch.min(recs, dim=0)
        
        if self.do_clamp and self.method == 'CS' or self.method == 'CM':
            x_hat = torch.clamp(x_hat, 0, 1)
        
        if self.method == 'BF':
            x_hat[x_hat == 0] = 0
            x_hat[x_hat > 0] = 1  
            
        return x_hat
        
    def SketchQuery_algorithms(self, x):
        if len(x.shape) == 3:
            # If there is batch size dim (Batch_size_dim x num_samples x n_dim) = (Batch_size_dimxnum_samples) x n_dim (2 dim)
            # Convert tensor of three dimencions to two
            x = x.view(x.shape[0]*x.shape[1],x.shape[2])
            
        s = self.sketch(x)
        x_hat = self.query(s)
        return x_hat, s
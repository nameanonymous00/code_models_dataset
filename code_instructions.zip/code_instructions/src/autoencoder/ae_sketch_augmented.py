import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch_optimizer as optim2
import numpy as np
import matplotlib.pyplot as plt
import sys
import random
sys.path.append('../../neural-sketch/src/')
sys.path.append('../../neural-sketch/')
sys.path.append('../../')
sys.path.append('../../../')
from src.models.frequency.countsketch import CountSketchQueryNetwork
from src.models.frequency.countmin import CountMinSketchQueryNetwork
from src.models.networks.sqnet import SketchNetwork, QueryNetworkTask
from src.models.networks.layers.residual import ResidualFC, ResidualFCwithPermute, ResidualFCLN
from src.models.networks.layers.permute import Permute
from src.datasets.zipf import get_zipf_probs, get_dataset_samples, ZipfOnlineDatasetLoader

from torchvision import datasets, transforms
print('done importing!')

class MeanDim(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, x):
        return torch.mean(x, dim=self.dim)

# Shared parameters
N_DIMS = 1000
w = 20
d = 5






with_mean = True
with_rf = False
with_sketch = True

batch_size = 1024+128*2
memory_samples = 64
optim_step = 20
device = 'cuda:2'

fine_tune = True
fine_tune_mean_to_sketch = False
mlp_type = 'LN'





transform = transforms.Compose([transforms.ToTensor(),
                              #transforms.Normalize((0.5,), (0.5,)),
                              ])
trainset = datasets.MNIST(download=True, train=True, transform=transform)
trainloadermnist = torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=True)

trainloadermnistmemory = torch.utils.data.DataLoader(trainset, batch_size=memory_samples, shuffle=True)
for x,y in trainloadermnist:
    print(x.shape, y.shape)
    break
print('done!')




def mnist_process_samples(x):
    img_eval = x.flatten(start_dim=2, end_dim=3).squeeze()
    img_eval = (img_eval > 0.3).float()
    padd_dim = 1000 - img_eval.shape[1]
    padding =  torch.zeros_like(img_eval)[:,0:padd_dim]
    img_eval = torch.cat([img_eval, padding], dim=1)
    return img_eval

img_eval =  mnist_process_samples(x)
img_eval_orig = torch.tensor(img_eval)



class ResNetMLP(torch.nn.Module):

    def __init__(self, in_dim, out_dim, hidden_dim=None, num_layers=3, input_bn=False, output_bn=False):
        super().__init__()
        
        if hidden_dim == None:
            hidden_dim = in_dim*2
        residual_layers = [ResidualFC(hidden_dim) for _ in range(num_layers)]
        self.net = nn.Sequential(
            nn.BatchNorm1d(in_dim, affine=False) if input_bn else nn.Identity(),
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.BatchNorm1d(hidden_dim),
            *residual_layers,
            nn.Linear(hidden_dim, out_dim),
            nn.BatchNorm1d(out_dim, affine=False) if output_bn else nn.Identity()
        )        
                
    def forward(self, x):
        y = self.net(x)
        return y


class ResNetMLPPermute(torch.nn.Module):

    def __init__(self, in_dim, out_dim, hidden_dim=None, num_layers=3, input_bn=False, output_bn=False):
        super().__init__()
        
        if hidden_dim == None:
            hidden_dim = in_dim*2
        residual_layers = [ResidualFCwithPermute(hidden_dim) for _ in range(num_layers)]
        self.net = nn.Sequential(
            nn.BatchNorm1d(in_dim, affine=False) if input_bn else nn.Identity(),
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            Permute((0,2,1)),
            nn.BatchNorm1d(hidden_dim),
            Permute((0,2,1)),
            *residual_layers,
            nn.Linear(hidden_dim, out_dim),
            Permute((0,2,1)),
            nn.BatchNorm1d(out_dim, affine=False) if output_bn else nn.Identity(),
            Permute((0,2,1)),
        )        
                
    def forward(self, x):
        y = self.net(x)
        return y

    
class ResNetMLPLN(torch.nn.Module):

    def __init__(self, in_dim, out_dim, hidden_dim=None, bottleneck_dim=None,num_layers=3, input_bn=False, output_bn=False):
        super().__init__()
        
        if hidden_dim == None:
            hidden_dim = in_dim*2
        residual_layers = [ResidualFCLN(hidden_dim, bottleneck_dim=bottleneck_dim) for _ in range(num_layers)]
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            *residual_layers,
            nn.Linear(hidden_dim, out_dim),
        )        
                
    def forward(self, x):
        y = self.net(x)
        return y





# Neural net training 

print('Setting up training!!!')

sketch_size = 50




rf_ratio = 4
sketch_ratio = 5

sn_input_dim = N_DIMS
qn_input_dim = sketch_size

if with_mean:
    qn_input_dim += N_DIMS
if with_rf:
    qn_input_dim += int(rf_ratio*N_DIMS)
if with_sketch:
    qn_input_dim += int(sketch_ratio*N_DIMS)
    
if with_mean:
    sn_input_dim += N_DIMS
if with_rf:
    sn_input_dim += int(rf_ratio*N_DIMS)
if with_sketch:
    sn_input_dim += int(sketch_ratio*N_DIMS)

    

encoder = ResNetMLPLN(sn_input_dim, sketch_size, hidden_dim=4096, bottleneck_dim=4096, num_layers=5).to(device)
decoder = ResNetMLPLN(qn_input_dim, N_DIMS, hidden_dim=4096, bottleneck_dim=4096, num_layers=5).to(device)

if with_rf:
    RF = nn.Sequential(*[nn.Linear(N_DIMS,int(N_DIMS*rf_ratio)),nn.ReLU(),MeanDim(1)]).to(device)
else:
    RF =  None
    
if with_sketch:
    sketch_net = nn.Sequential(*[ResNetMLPLN(N_DIMS, N_DIMS*sketch_ratio, hidden_dim=4096, bottleneck_dim=4096,  num_layers=3), MeanDim(1)]).to(device)
else:
    sketch_net = None
    

    

    
    
param_list = [*encoder.parameters(), *decoder.parameters()]

if with_sketch:
    param_list = [*encoder.parameters(), *decoder.parameters(), *sketch_net.parameters()]
if fine_tune_mean_to_sketch:
    param_list = [*sketch_net.parameters()]
    
criterion = nn.BCEWithLogitsLoss()

optimizer = optim2.RAdam(param_list, lr=0.000001, weight_decay=0.0)




def save_models(encoder, decoder, RF, sketch_net):
    name = 'sketch_augmented'
    if with_mean:
        name += '_with-mean_' 
    else:
        name += '_no-mean_'
    if with_rf:
        name += '_with-rf_' 
    else:
        name += '_no-rf_'
    if with_sketch:
        name += '_with-sketch_' 
    else:
        name += '_no-sketch_'

    sn_path = ''
    torch.save(encoder.state_dict(), sn_path)

    decoder_path = ''
    torch.save(decoder.state_dict(), decoder_path)

    if with_rf:
        rf_path = ''
        torch.save(RF.state_dict(), rf_path)

    if with_sketch:
        sketch_path = ''
        torch.save(sketch_net.state_dict(), sketch_path)
    print('model saved!')




best_mse = 99

print('Start training!!!')
num_epochs = 90000
print('num epochs are', num_epochs)
optimizer.zero_grad()







for j in range(num_epochs):
        
    
    for i, ((x,_), (x_mem,_)) in enumerate(zip(trainloadermnist, trainloadermnistmemory)):
        
        
        with torch.no_grad():
            
            x =  mnist_process_samples(x.to(device))
            x_mem = mnist_process_samples(x_mem.to(device))

            if torch.rand((1,)) > 0.5:
                x = 1 - x
                x_mem = 1 - x_mem
            
            x_mem = x_mem.unsqueeze(0)
            

            
            x_mem = torch.tensor(x_mem.repeat(x.shape[0],1, 1))

            
            for k in range(x.shape[0]):
                idx = torch.randperm(N_DIMS)               
                x_mem[k, :, :] = x_mem[k, :, idx]
                x[k, :] = x[k, idx]
            
            if with_mean:
                mean = torch.mean(x_mem, dim=1) 
                
            if with_rf:
                rf = RF(x_mem)
                

            
        

        
        
        
        if with_sketch:
            sketch = sketch_net(x_mem)


        
        x_ = x
        if with_mean:
            x_ = torch.cat([x_,mean], dim=1)
        if with_rf:
            x_ = torch.cat([x_,rf], dim=1)
        if with_sketch:
            x_ = torch.cat([x_,sketch], dim=1)
        
        z =  encoder(x_)
        
        
        if with_mean:
            z = torch.cat([z,mean], dim=1)
        if with_rf:
            z = torch.cat([z,rf], dim=1)
        if with_sketch:
            z = torch.cat([z,sketch], dim=1)

        
        query_output = decoder(z)
        loss = criterion(query_output, x) / optim_step

        loss.backward()
        
        if i % optim_step == 0:
            optimizer.step()
            optimizer.zero_grad()


        if i % (2*optim_step) == 0:
            print('Iter {} loss {} - best: {}'.format(j,loss.item(),best_mse))
            
            if loss.item() < best_mse:
                    best_mse = loss.item()
                    save_models(encoder, decoder, RF, sketch_net)
                    
    save_models(encoder, decoder, RF, sketch_net)
                    

                    

import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, TensorDataset
import torch.nn.functional as F
import sklearn
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from torch import Tensor
import numpy as np
import pandas as pd

class load_data():
    """
    Loads the data. The data must be compressed in a .npz. Inside the .npz, it must be three numpy arrays called train, test, and val (create_datasets class creates this compressed file).
    The dataset must be binary.
    """
    def __init__(self):
        super().__init__()
        
    def read_data(self,path):
        # Read data
        try:
            data = np.load(path)
            data_train = torch.from_numpy(data['train']).float()
            data_val = torch.from_numpy(data['val']).float()
            data_test = torch.from_numpy(data['test']).float()
        except:
            print('Error in reading data or data does not have the required fields. Inside the compressed file .npz it must be 3 numpy arrays with the following names: train, testa, and val')
            sys.exit(1)

        return data_train,data_val,data_test
        
    def loaddata(self,path=None):
        """
        Input:
            - path: Path of the dataset
        """
        if len(path.split('.npz')) == 2:
            # Load data and convert it to tensor
            return self.read_data(path)

        else:
            assert len(path.split('.npz')) != 2 , "Data should be in .npz format" 
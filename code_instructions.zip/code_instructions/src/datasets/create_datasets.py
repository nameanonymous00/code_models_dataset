import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, TensorDataset
import torch.nn.functional as F
import sklearn
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from torch import Tensor
import numpy as np
import pandas as pd

class save_data():
    """
    - The aim of this class is to read the date and separate it into train,test, and validation.
    
    - The input is the path of the file or files. If there is train and test data, the train data is separate it into train and validate. If there is no test data, the train data is separate it into train, test and validation.
      The three file are compress in a .npz. When loading the data, there are three arrays: train, test and validate in the same .npz.
    
    - The number of features of all the datasets will be 1000. So, if the number of features is smaller zero-padding is applied. If the number of features is bigger, we take the 1000 features with more frequency. (There is an exepcion, with the dogs datasets. In this dataset we take 1000 features at random).
    
    - All the features of the saved data need to be binary. So, the data is converted into one-hot encoding or is scaled and then binarized
    
    """
    def __init__(self):
        super().__init__()
         
    def read_dataset(self,path,name_data,binary_data_method):

        # Read numpy, text, and csv files
        if len(path.split('.npy')) == 2 or len(path.split('.csv')) == 2 or len(path.split('.txt')) == 2 or len(path.split('.npz')) == 2:

            # Read npy and npz
            if len(path.split('.npy')) == 2 or len(path.split('.npz')) == 2:
                data = np.load(path)
                if len(path.split('.npz')) == 2:
                    # Data in a .npz has to be treated different
                    x_train, y_train = data['a'], data['b']
                    data = torch.from_numpy(1-x_train).flatten(1)  

            # Read csv    
            else:
                data=pd.read_csv(path,sep=",")
                if data.shape[1] == 1:
                    data=pd.read_csv(path,sep=";")
                if name_data == 'KDD':
                    # Change the type of the column
                    data.iloc[:,8] = data.iloc[:,8].astype(str)  


        else:
            assert len(path.split('.npy')) != 2 or len(path.split('.csv')) != 2 or len(path.split('.txt')) != 2, "Data should be in numpy, txt, or csv format"
            
        print('dataset: {}, shape: {}'.format(name_data, data.shape))
        return data
    
    def load_data(self,data,name_data,binary_data_method):
        
        #### Read data and convert it to tensor
              
        # In dogs dataset if there are more than 1000 features, take at random 1000 features
        if name_data == 'dogs':
            # Take 1000 SNP at random
            idx = np.random.choice(np.arange(data.shape[1]), size=1000, replace=False)
            data = data[:,idx]


        if binary_data_method=='one_hot_encoding':
            #### Convert data to one-hot-encoding
            enc = sklearn.preprocessing.OneHotEncoder()

            # 2. FIT
            enc.fit(data)

            # 3. Transform
            data = enc.transform(data).toarray()   

        if binary_data_method=='binarized':
            # Scale data
            scaler = MinMaxScaler()
            data = scaler.fit_transform(data)
            # Binarized data
            data[data < 0.5]= 0
            data[data >= 0.5]= 1     

        # Convert numpy array into tensor   
        x = torch.from_numpy(data)#.float()

        # If the number of features is smaller than 1000 apply padding to arrive to 1000 features
        substract = 1000 - x.shape[1]

        if substract > 0:
            # Dimencion is smaller than 1000
            # Add zero padding
            num = substract/2
            # Even
            if num % 2 == 0:
                p1d = (int(num), int(num))
            else:
                num = int(num)
                p1d = (num, num+1)

            x = F.pad(x, p1d, "constant", 0)  # effectively zero padding

        # If the number of features is bigger than 1000, take the 1000 features with more frequecy
        if substract < 0:
            mean_features = torch.mean(x, dim=0)
            mean_features_sort,idx = torch.sort(mean_features,descending=True)
            print('Number of features : {} (bigger than 1000). Taking the 1000 with more frequency'.format(mean_features_sort.shape))
            # Take the 1000 first index, the ones that have more frequency
            idx_sorted = idx[0:1000]
            # Sort the indexes
            val = torch.sort(idx_sorted)

            return x[:,val.values]
            
        return x
            
        
    def load_MNIST_data(self,path):
        
        ## Load MNIST data
        transform = transforms.Compose([transforms.ToTensor(),
                                      #transforms.Normalize((0.5,), (0.5,)),
                                      ])
        # Load train
        trainset = datasets.MNIST(path,download=True, train=True, transform=transform)
        trainloader = torch.utils.data.DataLoader(trainset, batch_size=60000, shuffle=True)
        
        # Load test
        testset = datasets.MNIST(path,download=True, train=False, transform=transform)
        testloader = torch.utils.data.DataLoader(trainset, batch_size=60000, shuffle=True)        
        
        # train
        for i, data in enumerate(trainloader, 0):
            inputs, labels = data
            x_1 = inputs.flatten(start_dim=1)  
        
        # test
        for i, data in enumerate(testloader, 0):
            inputs, labels = data
            x_2 = inputs.flatten(start_dim=1)              
    
        # Concat data
        x = torch.cat((x_1,x_2), 0)
        
        # Scale data
        scaler = MinMaxScaler()
        inputs = scaler.fit_transform(x)
        # Binarize data
        inputs[inputs < 0.5]= 0
        inputs[inputs >= 0.5]= 1  

        # Convert to tensor
        inputs = torch.from_numpy(inputs)#.float()

        # Apply padding to arrive to 1000 features
        substract = 1000 - inputs.shape[1]
        if substract > 0:
            # Dimencion is smaller than 1000
            # Add zero padding
            num = substract/2
            # Even
            if num % 2 == 0:
                p1d = (int(num), int(num))
            else:
                num = int(num)
                p1d = (num, num+1)

            data = F.pad(inputs, p1d, "constant", 0)  # effectively zero padding
     
 
        return data
        
            
    def savedata(self,path,name_data,binary_data_method,output_folder):
        """
        Input:
            - path: Path of the train/test datasets or just train dataset
            - name_data: Name of the dataset. The dataset will be saved with this name
            - binary_data_method: 'binarized' if the features need to be binarized with a threshold, 'one_hot_encoding' if features need to be applied one hot, and 'none' if features are already binary.
            - output_folder: Folder where the dataset is going to be saved
        """
        # Data train and test
        #for path_data in path:
        # If there are two path, read both and concat the datasets 
        if len(path) == 2:
            # Read both datasets
            # Read data
            if name_data == 'MNIST':
                x = self.load_MNIST_data(path[0])
            else:
                x_1 = self.read_dataset(path[0],name_data,binary_data_method)    
                x_2 = self.read_dataset(path[1],name_data,binary_data_method)
                # Concat datasets
                data = np.concatenate((x_1, x_2))
                x = self.load_data(data,name_data,binary_data_method)
        else:
            # Just one dataset
            # If we just have train data
            data = self.read_dataset(path[0],name_data,binary_data_method)
            x = self.load_data(data,name_data,binary_data_method)
        
        # Divide data in test/train/val
        # X_train 80%, X_val 10%, X_test 10%         
        X_train, X_test_val = train_test_split(x, test_size=0.2) 
        X_val, X_test = train_test_split(X_test_val, test_size=0.5)     
            
        # Save train/test/val in a single .npz
        np.savez_compressed(output_folder+name_data, train=X_train, val=X_val, test=X_test)      
        
       
        return np.load(output_folder+name_data+'.npz')
    
    



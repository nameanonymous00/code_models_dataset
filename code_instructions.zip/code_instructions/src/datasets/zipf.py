import torch
import random

def get_zipf_probs(n_dims, alpha, beta):
    '''
    Returns a zipf distributed probabilities:
        zipf = beta^clamp(1-alpha, 0,1) * i^-alpha
        alpha: controls skewness (0 uniform, >1 very skewed)
        beta: controls "background" probability (when alpha=0 -> zipf=beta,  alpha>=1 -> zipf=i^-alpha)
    Where:
        i = 1...n_dims
        alpha >= 0
        0 <= beta =< 1
    '''
    lin = torch.linspace(0, n_dims-1, n_dims) + 1 # From 1 to n_dims
    x = (1 / (lin**alpha)) * (beta)**torch.clamp(torch.tensor(float(1-alpha)), min=0.0, max=1.0)
    return x





def get_dataset_samples(n_dims, num_batches, num_samples, alpha_min=0.0, alpha_max=2.0, beta_min=0.0, beta_max=1.0, alpha=None, beta=None):
    
    ps = []
    if alpha != None:
        alpha_list = [alpha for _ in range(num_batches)]
    else:
        alpha_list = list(torch.linspace(alpha_min, alpha_max, num_batches))
        random.shuffle(alpha_list)
        
    if beta != None:
        beta_list = [beta for _ in range(num_batches)]
    else:
        beta_list = list(torch.linspace(beta_min, beta_max, num_batches))
        random.shuffle(beta_list)
        
    for alpha, beta in zip(alpha_list, beta_list):
        ps.append(get_zipf_probs(n_dims, alpha, beta))
    ps = torch.stack(ps, dim=0)
    x = torch.bernoulli(ps.repeat(num_samples, 1, 1)).permute(1,0,2)
    return x




class ZipfOnlineDatasetLoader():
    def __init__(self, batch_size, n_dims, num_samples, shuffle_every_iter=True, resample_every_epoch=True, alpha_min=0.0, alpha_max=2.0, beta_min=0.0, beta_max=1.0, alpha=None, beta=None, virtual_num_batches=1000, device=None):
        self.batch_size = batch_size
        self.num_samples_per_batch = num_samples
        self.n_dims = n_dims
        
        self.alpha_min = alpha_min
        self.alpha_max = alpha_max
        self.beta_min = beta_min
        self.beta_max = beta_max
        self.alpha = alpha
        self.beta = beta

        self.shuffle_every_iter = shuffle_every_iter
        self.resample_every_epoch = resample_every_epoch
        self.device = device
        
        self.virtual_num_batches = virtual_num_batches
        self._index = 0
        
        self.do_resample()
        
        
    def __next__(self):
        
        if self._index == 0 and self.resample_every_epoch:
            self.do_resample()
        
        if self._index < self.virtual_num_batches:
            if self.shuffle_every_iter:
                self.do_shuffle()
            
            self._index += 1
            return self.x, self.y
        else:
            self._index = 0
            raise StopIteration
            
            
    def do_resample(self):
        self.x = get_dataset_samples(self.n_dims, self.batch_size, self.num_samples_per_batch, alpha_min=self.alpha_min, alpha_max=self.alpha_max, beta_min=self.beta_min, beta_max=self.beta_max, alpha=self.alpha, beta=self.beta)
        self.y = torch.mean(self.x, dim=1)
        
        if self.device != None:
            self.x = self.x.to(self.device)
            self.y = self.y.to(self.device)
        
        
        
    def do_shuffle(self):
        with torch.no_grad():
            idx = torch.randperm(self.n_dims)
            self.x, self.y = self.x[:, :, idx], self.y[:, idx]

            idx = torch.randperm(self.batch_size)
            self.x, self.y = self.x[idx, :, :], self.y[idx, :]
        
            
    def __iter__(self):
        return self
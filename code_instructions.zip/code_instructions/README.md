# Learning Sketches with Neural Networks

This repo includes the source code for learning sketches for approximate query processing with neural networks


## Frequency and Membership estimation tasks

In the frequency and membership estimation tasks, we explore the SQNEt and RFQNet. In the SQNet we trained the Sketch and Query networks and in the RFQNet just the Query network.
The objective is to compare the results with Count Min Sketch(CM) and Count Sketch (CS) in the frequency estimation task, and with Bloom filters (BF) in the membership estimation task.

The scripts and notebooks of the frequency and membership estimation can be find in the following folders:

* neural-sketch/configs/
* neural-sketch/notebooks/1_datasets/
* neural-sketch/notebooks/2_frequency/
* neural-sketch/notebooks/3_membership/
* neural-sketch/results/
* neural-sketch/src/datasets
* neural-sketch/src/models/frequency
* neural-sketch/src/models/frequency
* neural-sketch/src/models/scripts/frequency_membership

The configs folder contains the configuration, parameters, and hyperparameters of the scripts.
The notebook folder has 3 folders inside. The 1_dataset which has some notebooks exploring the datasets, and the 2_frequency and 3_membership folders which contain the same notebooks, but ones are with the frequency task, and the others with the membership task.
The src folder contains the .py python files used to do the experiments.

### Datasets and models

In this project, we use 10 different datasets. 9 of them can be found in https://figshare.com/projects/Datasets_and_Models/140122, and the other is the Zipf that we simulated. All the datasets are binary and preprocessed to have 1000 features.
In the notebook zipf_demo we find different plots of the Zipf dataset, and in the Binary_datasets notebook, we find plots of the other datasets. At the top of this last notebook is called a class that preprocesses and saves the new datasets to neural-sketch/results/datasets. If you download the datasets from https://figshare.com/projects/Datasets_and_Models/140122 you should NOT execute it. You should just execute it if you download the datasets from the original web and they are not preprocessed.

To use the datasets, you should download them from the ULR and save them in the folder neural-sketch/results/datasets

The best models using a sketch size of 100 are in the following https://drive.google.com/drive/folders/1P_cwS-Vc3aj1bFvKwvxAXhGdUayUrHf4?usp=sharing. To use the models you should download and save them in the folder neural-sketch/results/networks/networks_sketch_100. Inside the folder networks, there are several folders. You should upload your models to the corresponding folder, depending on the task (frequency or membership) and if is SQNet or RFQNet. 
If you download the models, you will find a folder called f that contains  the frequency models, and they should go to the following folder in the repository:

* networks_frequency_rf: snet_sq_gelu0.6.pth and qnet_sq_gelu0.6.pth
* networks_frequency_sqnet: snet_sq_Mean.pth and qnet_sq_Mean.pth

and the membership models are in a folder called m, and should go to:

* networks_membership_rf: snet_sq_gelu0.6.pth and qnet_sq_gelu0.6.pth
* networks_membership_sqnet_residual: snet_sq_Min.pth and qnet_sq_Min.pth


### Configs

1. config_frequencymodels.txt: Contain two lists with d and w (d*w=sketch size). This file should not be modified. The trained scripts just support sketch sizes of 10,100,500, and 1000. 

2. config_network.txt: Contain the parameters and hyperparameters to train the networks.

    
        "task":'frequency_estimation' or 'membership_estimation'
        "train_SN_QN": 1 (sqnet) or 0 (rfqnet)
        'both_sq_rfq':0 (just training RFQnet or SQNet), 1 (if you want to train both)
        "sketch_size":10 or 100 or 500 or 1000 
        "n_dims": 1000,
        "weight_decay":0.000001,
        "num_samples_net":10, 
        "num_samples":100 (frequency) or10 (membership)
        "num_epochs":80,
        "hidden_dim":2000,    
        "save_plots": 1 or 0
        
        # SQNET ("train_SN_QN": 1)
        "residual_sketch_net": 0 (SketchNetwork) or 1 (SketchNetworkResLN)
        'num_hidden':1,
        "lr_sq":0.00001,
        "batch_size_sq":500,
        "type_lastlayer_sq":'Mean' or 'Min' or 'Max' or 'Log-sum-exp' or 'p-norm' or '-1*log-sum-exp(-x)' or '-1*p-norm(-x)'
        "order_norm_sq":2, # from 2 to 10

        # RFnet ("train_SN_QN": 0)
        "lr_rf":0.00001,
        "batch_size_rf":512,
        "var":0.6,
        "type_lastlayer_rf":'Mean', # always Mean
        "order_norm_rf":2,
        "activation":'relu' or 'lrelu' or 'gelu' or 'tanh' or 'sigmoid' or 'cos' or 'sin' or 'rff'

        "name_hyperparam":'activation', # hyperparam you want to optimize
        "list_hyperparam": ['relu','lrelu','gelu','tanh','sigmoid','cos','sin','rff'], # values used for the name_hyperparam
        "path_opt_CM":'../../../results/benchmark_wd/optimum_w_d_CM_sketch_10.csv',
        "path_opt_CS":'../../../results/benchmark_wd/optimum_w_d_CS_sketch_10.csv',
        "path_opt_BF":'../../../results/benchmark_wd/optimum_w_d_BF_sketch_100.csv',
        "path_networks_sqnet":'../../../results/networks/networks_sketch_10/networks_frequency_sqnet/',
        "path_networks_rfqnet":'../../../results/networks/networks_sketch_10/networks_frequency_rf/',

3. config_frequencymodel_sk100.txt: Contain the parameters and hyperparameters of the trained networks. This file is used in the scripts to evaluate the networks. The content of the file is very similar to the config_network.txt, but in this file are defined the best models of the frequency estimation task.

4. config_membershipmodel_sk100.txt: Contain the parameters and hyperparameters to train the networks. This file is used in the scripts to evaluate the networks. The content of the file is very similar to the config_network.txt, but in this file are defined the best models of the membership estimation task.


### Functionalities:

* Search the best hyperparameters of BF/CS/CM.
* Train RFQNet and/or SQNet with Zipf dataset.
* Evaluate BF, CS, CM, RFQNet, and SQNet with the models trained and with the Zipf dataset.
* Evaluate RFQNet and/or SQNet trained models with Zipf with other datasets.
* Train the tasks with other datasets initializing the models with the already trained with Zipf.


#### Search the best hyperparameters of BF/CS/CM

In the neural-sketch/results/benchmark_wd you will find some NumPy and CSV files. The NumPy contains the MSE error of all the combinations of alpha, beta, w, and d executed 5 or 10 times. The CSV contains the MSE error of the best hyperparameters (d and w) for each combination of alpha and beta.
These files are generated with the following commands:
```
     cd neural-sketch/src/scripts/frequency_membership/
     python3 bestparameters_BF.py -Sketch_size 100
     python3 bestparameters_CM_CS.py -Sketch_size 100
```
The sketch size can be 10,100,500,1000.
In the notebooks hyperparameter_search_CM_CS.ipynb and hyperparameter_search_BF.ipynb, the NumPy files are loaded and there are performed several plots. This plots are saved in neural-sketch/results/plots_CM_CS_BF.

In the notebooks countmin_countsketch_benchmark.ipynb, countmin_countsketch.ipynb, and blom_filters.ipynb there several experiments with different d and w using a sketch size 100 and 10.

#### Train RFQNet and/or SQNet with Zipf dataset

As mentioned, you can download the best models from https://drive.google.com/drive/folders/1P_cwS-Vc3aj1bFvKwvxAXhGdUayUrHf4?usp=sharing, and should be added to the indicated folders.
If you want to train the models, you can just train SQNet or RFQNet, or both. The configuration and hyperparameters are in config_frequencymodels.txt and config_networks.txt.
The models are saved in neural-sketch/results/networks/networks_sketch_100 and a plot with the loss of the models in neural-sketch/results/results_loss_trained_zipf.

#### Evaluate BF, CS, CM, RFQNet, and SQNet with the models trained and with the Zipf dataset

The notebook Evaluate_zipfnets_withzipf.ipynb evaluates the networks trained with Zipf dataset doing a plot with errors of CM/CS or BF and SQNet/RFQNet. These plots are saved in neural-sketch/results/plots_zipf. This notebook uses the config_frequencymodel_sk100.txt or config_membershipmodel_sk100.txt to define all the configuration, parameters, and hyperparameters.

There is another notebook called Evaluate_zipfnets_withzipf_comparation_plots.ipynb that evaluates the different hyperparameters. These plots are saved in neural-sketch/results/plots_comparison_zipf.

#### Evaluate RFQNet and/or SQNet trained models with Zipf with other datasets.

The notebook Evaluate_zipfnets_withdifferent_datasets_sketch100.ipynb evaluates the networks trained with the Zipf dataset in the train_sqn.py computing the error with other datasets. This notebook shows a table with the CM/CS or BF and SQNet/RFQNet errors using the different datasets. The table shown is not saved, just displayed in the notebook. This notebook uses the config_frequencymodel_sk100.txt or config_membershipmodel_sk100.txt to define all the configuration, parameters, and hyperparameters.

#### Train the tasks with other datasets initializing the models with the trained models with Zipf.

The script train_sqn_alldatasets.py trains the SQNet and RFQNet with the datasets that are in https://figshare.com/projects/Datasets_and_Models/140122. The networks are initialized with the networks trained with the Zipf dataset. The output is a table with the test MSE errors, and is saved in neural-sketch/results/results_errors_trained_datasets.
The hyperparameters and parameters are defined in the config files: config_frequencymodel_sk100.txt and config_membershipmodel_sk100.txt depending on the task that you want to do.
```
     cd neural-sketch/src/scripts/frequency_membership/
     python3 train_sqn_alldatasets.py -task frequency
     python3 train_sqn_alldatasets.py -task membership
```

#### Train and evaluate k-means

Scripts for training and evaluating compressive k-means are included in src/k-means

#### Train and evaluate autoencoders

Scripts for training and evaluating autoencoders can be found in src/autoencoder -- note that training can take a long time!


## License

This code is propietary and can not be shared or used for commercial or resarch purposes without permision of the authors.